"use client"

import Link from "next/link"
import { motion } from "framer-motion"
import {
  ChevronLeft,
  Target,
  Search,
  Unlock,
  BarChart2,
  MessageCircle,
  TrendingUp,
  Handshake,
  Award,
  Heart,
  Cpu,
  Home,
  Flag,
} from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Header } from "@/components/layout/header"
import { Footer } from "@/components/layout/footer"
import { PageHero } from "@/components/ui/page-hero"
import { objectives } from "@/lib/data"

const iconMap: Record<string, React.ComponentType<{ className?: string }>> = {
  Search,
  Unlock,
  BarChart2,
  MessageCircle,
  TrendingUp,
  Handshake,
  Award,
  Heart,
  Cpu,
  Target,
}

export default function ObjectivesPage() {
  return (
    <div className="min-h-screen flex flex-col">
      <Header />

      <main className="flex-1">
        <PageHero
          title={objectives.title}
          subtitle={objectives.subtitle}
          description="الأهداف العامة والخاصة التي نسعى لتحقيقها من خلال منصة نوران"
          breadcrumbs={[
            { label: "الرئيسية", href: "/" },
            { label: "الأهداف", href: "/objectives" },
          ]}
        />

        {/* Main Objective */}
        <section className="py-16 bg-primary text-primary-foreground">
          <div className="container mx-auto px-4">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              className="max-w-4xl mx-auto text-center"
            >
              <div className="w-20 h-20 rounded-full bg-white/10 flex items-center justify-center mx-auto mb-8">
                <Flag className="h-10 w-10 text-accent" />
              </div>
              <h2 className="text-2xl md:text-3xl font-bold mb-6">
                {objectives.mainObjective.title}
              </h2>
              <p className="text-xl text-primary-foreground/90 leading-relaxed">
                {objectives.mainObjective.description}
              </p>
            </motion.div>
          </div>
        </section>

        {/* Specific Objectives */}
        <section className="py-16 md:py-24 bg-background">
          <div className="container mx-auto px-4">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              className="text-center mb-16"
            >
              <h2 className="text-2xl md:text-3xl font-bold text-foreground mb-4">
                الأهداف الخاصة
              </h2>
              <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
                الأهداف التفصيلية التي تترجم الهدف العام إلى نتائج قابلة للقياس
              </p>
            </motion.div>

            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
              {objectives.specificObjectives.map((objective, index) => {
                const IconComponent = iconMap[objective.icon] || Target
                return (
                  <motion.div
                    key={index}
                    initial={{ opacity: 0, y: 20 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    viewport={{ once: true }}
                    transition={{ duration: 0.5, delay: index * 0.1 }}
                  >
                    <Card className="h-full hover:shadow-xl hover:border-primary/30 transition-all duration-300 group">
                      <CardContent className="p-6">
                        <div className="flex items-start gap-4">
                          <div className="w-14 h-14 rounded-xl bg-gradient-to-br from-primary to-primary/80 flex items-center justify-center flex-shrink-0 group-hover:scale-110 transition-transform">
                            <IconComponent className="h-7 w-7 text-primary-foreground" />
                          </div>
                          <div className="flex-1 min-w-0">
                            <h3 className="text-lg font-bold text-foreground mb-2 group-hover:text-primary transition-colors">
                              {objective.title}
                            </h3>
                            <p className="text-muted-foreground text-sm leading-relaxed">
                              {objective.description}
                            </p>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  </motion.div>
                )
              })}
            </div>
          </div>
        </section>

        {/* Navigation */}
        <section className="py-12 bg-muted/30 border-t border-border">
          <div className="container mx-auto px-4">
            <div className="flex flex-col sm:flex-row items-center justify-between gap-4">
              <Button asChild variant="outline" className="group">
                <Link href="/">
                  <Home className="ml-2 h-4 w-4" />
                  العودة للرئيسية
                </Link>
              </Button>
              <div className="flex items-center gap-4">
                <Button asChild variant="outline" className="group">
                  <Link href="/team">
                    <ChevronLeft className="ml-2 h-4 w-4 rotate-180" />
                    فريق العمل
                  </Link>
                </Button>
                <Button asChild className="group">
                  <Link href="/timeline">
                    الجدول الزمني
                    <ChevronLeft className="mr-2 h-4 w-4" />
                  </Link>
                </Button>
              </div>
            </div>
          </div>
        </section>
      </main>

      <Footer />
    </div>
  )
}
