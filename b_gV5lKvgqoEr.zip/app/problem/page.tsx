"use client"

import Link from "next/link"
import { motion } from "framer-motion"
import {
  ArrowLeft,
  ArrowRight,
  EyeOff,
  GraduationCap,
  Lock,
  Cpu,
  AlertTriangle,
  MessageSquareOff,
  XCircle,
} from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Header } from "@/components/layout/header"
import { Footer } from "@/components/layout/footer"
import { PageHero } from "@/components/ui/page-hero"
import { problem } from "@/lib/data"

const iconMap: Record<string, React.ComponentType<{ className?: string }>> = {
  EyeOff,
  GraduationCap,
  Lock,
  Cpu,
  AlertTriangle,
  MessageSquareOff,
}

export default function ProblemPage() {
  return (
    <div className="min-h-screen flex flex-col">
      <Header />

      <main className="flex-1">
        <PageHero
          title={problem.title}
          subtitle={problem.subtitle}
          description={problem.description}
          breadcrumbs={[{ label: "فكرة المشروع / المشكلة" }]}
        />

        {/* Challenges Section */}
        <section className="py-16 md:py-24 bg-background">
          <div className="container mx-auto px-4">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
              className="text-center mb-16"
            >
              <h2 className="text-2xl md:text-3xl font-bold text-foreground mb-4">
                الإشكالات الرئيسية
              </h2>
              <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
                تعاني منظومة الصفقات العمومية من مجموعة من التحديات البنيوية
              </p>
            </motion.div>

            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
              {problem.challenges.map((challenge, index) => {
                const IconComponent = iconMap[challenge.icon] || AlertTriangle
                return (
                  <motion.div
                    key={index}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.5, delay: index * 0.1 }}
                  >
                    <Card className="h-full border-destructive/20 bg-destructive/5 hover:shadow-lg transition-all">
                      <CardHeader>
                        <div className="w-14 h-14 rounded-xl bg-destructive/10 flex items-center justify-center mb-4">
                          <IconComponent className="h-7 w-7 text-destructive" />
                        </div>
                        <CardTitle className="text-lg">{challenge.title}</CardTitle>
                      </CardHeader>
                      <CardContent>
                        <p className="text-muted-foreground">
                          {challenge.description}
                        </p>
                      </CardContent>
                    </Card>
                  </motion.div>
                )
              })}
            </div>
          </div>
        </section>

        {/* Consequences Section */}
        <section className="py-16 md:py-24 bg-muted/30">
          <div className="container mx-auto px-4">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              className="max-w-4xl mx-auto"
            >
              <div className="text-center mb-12">
                <h2 className="text-2xl md:text-3xl font-bold text-foreground mb-4">
                  النتائج والعواقب
                </h2>
                <p className="text-lg text-muted-foreground">
                  تؤدي هذه الإشكالات إلى عواقب وخيمة على المستوى الاقتصادي والاجتماعي
                </p>
              </div>

              <div className="grid md:grid-cols-2 gap-4">
                {problem.consequences.map((consequence, index) => (
                  <motion.div
                    key={index}
                    initial={{ opacity: 0, x: index % 2 === 0 ? 20 : -20 }}
                    whileInView={{ opacity: 1, x: 0 }}
                    viewport={{ once: true }}
                    transition={{ duration: 0.5, delay: index * 0.1 }}
                  >
                    <Card className="border-border/50 hover:border-destructive/30 transition-colors">
                      <CardContent className="p-4 flex items-center gap-4">
                        <div className="w-10 h-10 rounded-full bg-destructive/10 flex items-center justify-center flex-shrink-0">
                          <XCircle className="h-5 w-5 text-destructive" />
                        </div>
                        <p className="text-foreground">{consequence}</p>
                      </CardContent>
                    </Card>
                  </motion.div>
                ))}
              </div>
            </motion.div>
          </div>
        </section>

        {/* Call to Action */}
        <section className="py-16 bg-primary text-primary-foreground">
          <div className="container mx-auto px-4">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              className="max-w-3xl mx-auto text-center"
            >
              <h2 className="text-2xl md:text-3xl font-bold mb-6">
                الحل موجود: منصة نوران
              </h2>
              <p className="text-lg text-primary-foreground/90 mb-8">
                تقدم منصة نوران حلاً رقمياً مبتكراً يعالج هذه التحديات من خلال
                توظيف التكنولوجيا والبيانات لتعزيز الشفافية والحكامة الجيدة
              </p>
              <Button
                asChild
                size="lg"
                className="bg-accent hover:bg-accent/90 text-accent-foreground group"
              >
                <Link href="/solution">
                  اكتشف الحل المقترح
                  <ArrowLeft className="mr-2 h-4 w-4 group-hover:-translate-x-1 transition-transform" />
                </Link>
              </Button>
            </motion.div>
          </div>
        </section>

        {/* Navigation */}
        <section className="py-8 bg-background border-t border-border">
          <div className="container mx-auto px-4">
            <div className="flex items-center justify-between">
              <Button asChild variant="ghost" className="group">
                <Link href="/introduction">
                  <ArrowRight className="ml-2 h-4 w-4 group-hover:translate-x-1 transition-transform" />
                  مقدمة
                </Link>
              </Button>
              <Button asChild className="group">
                <Link href="/solution">
                  الحل المقترح
                  <ArrowLeft className="mr-2 h-4 w-4 group-hover:-translate-x-1 transition-transform" />
                </Link>
              </Button>
            </div>
          </div>
        </section>
      </main>

      <Footer />
    </div>
  )
}
