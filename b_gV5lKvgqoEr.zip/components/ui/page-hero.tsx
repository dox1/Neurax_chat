"use client"

import Link from "next/link"
import { ChevronLeft, Home } from "lucide-react"
import { cn } from "@/lib/utils"

interface BreadcrumbItem {
  label: string
  href?: string
}

interface PageHeroProps {
  title: string
  subtitle?: string
  description?: string
  breadcrumbs: BreadcrumbItem[]
  className?: string
}

export function PageHero({
  title,
  subtitle,
  description,
  breadcrumbs,
  className,
}: PageHeroProps) {
  return (
    <section
      className={cn(
        "relative bg-gradient-to-bl from-primary via-primary to-primary/90 text-primary-foreground py-16 md:py-24 overflow-hidden",
        className
      )}
    >
      {/* Background Pattern */}
      <div className="absolute inset-0 opacity-10">
        <div className="absolute inset-0" style={{
          backgroundImage: `url("data:image/svg+xml,%3Csvg width='60' height='60' viewBox='0 0 60 60' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='none' fill-rule='evenodd'%3E%3Cg fill='%23ffffff' fill-opacity='0.4'%3E%3Cpath d='M36 34v-4h-2v4h-4v2h4v4h2v-4h4v-2h-4zm0-30V0h-2v4h-4v2h4v4h2V6h4V4h-4zM6 34v-4H4v4H0v2h4v4h2v-4h4v-2H6zM6 4V0H4v4H0v2h4v4h2V6h4V4H6z'/%3E%3C/g%3E%3C/g%3E%3C/svg%3E")`,
        }} />
      </div>

      {/* Accent Elements */}
      <div className="absolute top-0 left-0 w-64 h-64 bg-accent/20 rounded-full blur-3xl -translate-x-1/2 -translate-y-1/2" />
      <div className="absolute bottom-0 right-0 w-96 h-96 bg-accent/10 rounded-full blur-3xl translate-x-1/2 translate-y-1/2" />

      <div className="container mx-auto px-4 relative z-10">
        {/* Breadcrumbs */}
        <nav aria-label="Breadcrumb" className="mb-8">
          <ol className="flex items-center gap-2 text-sm text-primary-foreground/80">
            <li>
              <Link
                href="/"
                className="flex items-center gap-1 hover:text-accent transition-colors"
              >
                <Home className="h-4 w-4" />
                <span className="sr-only">الرئيسية</span>
              </Link>
            </li>
            {breadcrumbs.map((item, index) => (
              <li key={index} className="flex items-center gap-2">
                <ChevronLeft className="h-4 w-4 opacity-50" />
                {item.href ? (
                  <Link
                    href={item.href}
                    className="hover:text-accent transition-colors"
                  >
                    {item.label}
                  </Link>
                ) : (
                  <span className="text-primary-foreground font-medium">
                    {item.label}
                  </span>
                )}
              </li>
            ))}
          </ol>
        </nav>

        {/* Content */}
        <div className="max-w-3xl">
          {subtitle && (
            <p className="text-accent font-medium mb-3 animate-fade-in-up">
              {subtitle}
            </p>
          )}
          <h1 className="text-3xl md:text-4xl lg:text-5xl font-bold mb-6 animate-fade-in-up stagger-1">
            {title}
          </h1>
          {description && (
            <p className="text-lg md:text-xl text-primary-foreground/90 leading-relaxed animate-fade-in-up stagger-2">
              {description}
            </p>
          )}
        </div>

        {/* Decorative Line */}
        <div className="mt-8 flex items-center gap-4 animate-fade-in-up stagger-3">
          <div className="w-16 h-1 bg-accent rounded-full" />
          <div className="w-8 h-1 bg-accent/50 rounded-full" />
          <div className="w-4 h-1 bg-accent/30 rounded-full" />
        </div>
      </div>
    </section>
  )
}
