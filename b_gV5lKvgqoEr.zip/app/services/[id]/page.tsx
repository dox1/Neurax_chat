"use client"

import Link from "next/link"
import { useParams } from "next/navigation"
import { motion } from "framer-motion"
import {
  ArrowLeft,
  ChevronLeft,
  Home,
  FileSearch,
  BookOpen,
  AlertOctagon,
  LayoutDashboard,
  BarChart3,
  Shield,
  MessageSquare,
  GraduationCap,
  Target,
  CheckCircle2,
} from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Header } from "@/components/layout/header"
import { Footer } from "@/components/layout/footer"
import { PageHero } from "@/components/ui/page-hero"
import { services } from "@/lib/data"

const iconMap: Record<string, React.ComponentType<{ className?: string }>> = {
  FileSearch,
  BookOpen,
  AlertOctagon,
  LayoutDashboard,
  BarChart3,
  Shield,
  MessageSquare,
  GraduationCap,
  Target,
}

export default function ServiceDetailPage() {
  const params = useParams()
  const serviceId = params.id as string
  
  const service = services.items.find(s => s.id === serviceId)
  const currentIndex = services.items.findIndex(s => s.id === serviceId)
  const prevService = currentIndex > 0 ? services.items[currentIndex - 1] : null
  const nextService = currentIndex < services.items.length - 1 ? services.items[currentIndex + 1] : null

  if (!service) {
    return (
      <div className="min-h-screen flex flex-col">
        <Header />
        <main className="flex-1 flex items-center justify-center">
          <div className="text-center">
            <h1 className="text-2xl font-bold mb-4">الخدمة غير موجودة</h1>
            <Button asChild>
              <Link href="/services">العودة للخدمات</Link>
            </Button>
          </div>
        </main>
        <Footer />
      </div>
    )
  }

  const IconComponent = iconMap[service.icon] || Target

  return (
    <div className="min-h-screen flex flex-col">
      <Header />

      <main className="flex-1">
        <PageHero
          title={service.title}
          subtitle="تفاصيل الخدمة"
          description={service.shortDescription}
          breadcrumbs={[
            { label: "الرئيسية", href: "/" },
            { label: "الخدمات", href: "/services" },
            { label: service.title, href: `/services/${service.id}` },
          ]}
        />

        <section className="py-16 md:py-24 bg-background">
          <div className="container mx-auto px-4">
            <div className="max-w-4xl mx-auto">
              {/* Service Icon & Description */}
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                className="text-center mb-16"
              >
                <div className="w-24 h-24 rounded-2xl bg-gradient-to-br from-primary to-primary/80 flex items-center justify-center mx-auto mb-8">
                  <IconComponent className="h-12 w-12 text-primary-foreground" />
                </div>
                <p className="text-lg text-muted-foreground leading-relaxed max-w-2xl mx-auto">
                  {service.fullDescription}
                </p>
              </motion.div>

              {/* Features */}
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
              >
                <h2 className="text-2xl font-bold text-foreground mb-8 text-center">
                  مميزات الخدمة
                </h2>
                <div className="grid md:grid-cols-2 gap-4">
                  {service.features.map((feature, index) => (
                    <motion.div
                      key={index}
                      initial={{ opacity: 0, x: 20 }}
                      whileInView={{ opacity: 1, x: 0 }}
                      viewport={{ once: true }}
                      transition={{ duration: 0.5, delay: index * 0.1 }}
                    >
                      <Card className="h-full hover:shadow-lg hover:border-primary/30 transition-all">
                        <CardContent className="p-6">
                          <div className="flex items-start gap-4">
                            <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center flex-shrink-0">
                              <CheckCircle2 className="h-5 w-5 text-primary" />
                            </div>
                            <p className="text-foreground font-medium pt-2">{feature}</p>
                          </div>
                        </CardContent>
                      </Card>
                    </motion.div>
                  ))}
                </div>
              </motion.div>
            </div>
          </div>
        </section>

        {/* Related Services */}
        <section className="py-16 bg-muted/30">
          <div className="container mx-auto px-4">
            <h2 className="text-2xl font-bold text-foreground mb-8 text-center">
              خدمات أخرى
            </h2>
            <div className="grid md:grid-cols-3 gap-6 max-w-4xl mx-auto">
              {services.items.filter(s => s.id !== serviceId).slice(0, 3).map((relatedService, index) => {
                const RelatedIcon = iconMap[relatedService.icon] || Target
                return (
                  <motion.div
                    key={relatedService.id}
                    initial={{ opacity: 0, y: 20 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    viewport={{ once: true }}
                    transition={{ duration: 0.5, delay: index * 0.1 }}
                  >
                    <Link href={`/services/${relatedService.id}`} className="block group">
                      <Card className="h-full hover:shadow-lg hover:border-primary/30 transition-all">
                        <CardContent className="p-6 text-center">
                          <div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center mx-auto mb-4 group-hover:bg-primary transition-colors">
                            <RelatedIcon className="h-6 w-6 text-primary group-hover:text-primary-foreground transition-colors" />
                          </div>
                          <h3 className="font-semibold text-foreground group-hover:text-primary transition-colors">
                            {relatedService.title}
                          </h3>
                        </CardContent>
                      </Card>
                    </Link>
                  </motion.div>
                )
              })}
            </div>
          </div>
        </section>

        {/* Navigation */}
        <section className="py-12 bg-background border-t border-border">
          <div className="container mx-auto px-4">
            <div className="flex flex-col sm:flex-row items-center justify-between gap-4">
              <Button asChild variant="outline" className="group">
                <Link href="/services">
                  <ArrowLeft className="ml-2 h-4 w-4 rotate-180" />
                  جميع الخدمات
                </Link>
              </Button>
              <div className="flex items-center gap-4">
                {prevService && (
                  <Button asChild variant="outline" className="group">
                    <Link href={`/services/${prevService.id}`}>
                      <ChevronLeft className="ml-2 h-4 w-4 rotate-180" />
                      {prevService.title}
                    </Link>
                  </Button>
                )}
                {nextService && (
                  <Button asChild className="group">
                    <Link href={`/services/${nextService.id}`}>
                      {nextService.title}
                      <ChevronLeft className="mr-2 h-4 w-4" />
                    </Link>
                  </Button>
                )}
              </div>
            </div>
          </div>
        </section>
      </main>

      <Footer />
    </div>
  )
}
