"use client"

import Link from "next/link"
import { motion } from "framer-motion"
import {
  ChevronLeft,
  Cpu,
  Shield,
  Settings,
  Eye,
  Users,
  Lock,
  Rocket,
  Monitor,
  Building,
  Layers,
  Maximize,
  Home,
  Lightbulb,
  CheckCircle2,
} from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion"
import { Header } from "@/components/layout/header"
import { Footer } from "@/components/layout/footer"
import { PageHero } from "@/components/ui/page-hero"
import { innovation } from "@/lib/data"

const iconMap: Record<string, React.ComponentType<{ className?: string }>> = {
  Cpu,
  Shield,
  Settings,
  Eye,
  Users,
  Lock,
  Rocket,
  Monitor,
  Building,
  Layers,
  Maximize,
}

export default function InnovationPage() {
  return (
    <div className="min-h-screen flex flex-col">
      <Header />

      <main className="flex-1">
        <PageHero
          title={innovation.title}
          subtitle={innovation.subtitle}
          description={innovation.description}
          breadcrumbs={[
            { label: "الرئيسية", href: "/" },
            { label: "الجوانب الابتكارية", href: "/innovation" },
          ]}
        />

        {/* Innovation Aspects */}
        <section className="py-16 md:py-24 bg-background">
          <div className="container mx-auto px-4">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              className="text-center mb-16"
            >
              <h2 className="text-2xl md:text-3xl font-bold text-foreground mb-4">
                جوانب الابتكار
              </h2>
              <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
                تتميز منصة نوران بمجموعة متنوعة من الجوانب الابتكارية
              </p>
            </motion.div>

            <div className="max-w-4xl mx-auto">
              <Accordion type="single" collapsible className="space-y-4">
                {innovation.aspects.map((aspect, index) => {
                  const IconComponent = iconMap[aspect.icon] || Lightbulb
                  return (
                    <motion.div
                      key={index}
                      initial={{ opacity: 0, y: 20 }}
                      whileInView={{ opacity: 1, y: 0 }}
                      viewport={{ once: true }}
                      transition={{ duration: 0.5, delay: index * 0.1 }}
                    >
                      <AccordionItem value={`item-${index}`} className="border rounded-xl px-6 bg-card hover:shadow-lg transition-shadow">
                        <AccordionTrigger className="hover:no-underline py-6">
                          <div className="flex items-center gap-4 text-right">
                            <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-primary to-primary/80 flex items-center justify-center flex-shrink-0">
                              <IconComponent className="h-6 w-6 text-primary-foreground" />
                            </div>
                            <div>
                              <h3 className="font-bold text-foreground text-lg">{aspect.title}</h3>
                              <p className="text-sm text-muted-foreground mt-1">{aspect.description}</p>
                            </div>
                          </div>
                        </AccordionTrigger>
                        <AccordionContent className="pb-6">
                          <div className="pr-16">
                            <ul className="grid md:grid-cols-2 gap-3">
                              {aspect.details.map((detail, i) => (
                                <li key={i} className="flex items-center gap-3">
                                  <CheckCircle2 className="h-5 w-5 text-primary flex-shrink-0" />
                                  <span className="text-muted-foreground">{detail}</span>
                                </li>
                              ))}
                            </ul>
                          </div>
                        </AccordionContent>
                      </AccordionItem>
                    </motion.div>
                  )
                })}
              </Accordion>
            </div>
          </div>
        </section>

        {/* Innovation Domains */}
        <section className="py-16 bg-muted/30">
          <div className="container mx-auto px-4">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              className="text-center mb-12"
            >
              <h2 className="text-2xl md:text-3xl font-bold text-foreground mb-4">
                مجالات الابتكار
              </h2>
            </motion.div>

            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 max-w-4xl mx-auto">
              {innovation.domains.map((domain, index) => {
                const IconComponent = iconMap[domain.icon] || Lightbulb
                return (
                  <motion.div
                    key={index}
                    initial={{ opacity: 0, scale: 0.9 }}
                    whileInView={{ opacity: 1, scale: 1 }}
                    viewport={{ once: true }}
                    transition={{ duration: 0.5, delay: index * 0.1 }}
                  >
                    <Card className="h-full text-center hover:shadow-lg hover:border-primary/30 transition-all duration-300 group">
                      <CardContent className="p-6">
                        <div className="w-14 h-14 rounded-xl bg-primary/10 flex items-center justify-center mx-auto mb-4 group-hover:bg-primary group-hover:text-primary-foreground transition-colors">
                          <IconComponent className="h-7 w-7 text-primary group-hover:text-primary-foreground transition-colors" />
                        </div>
                        <h3 className="font-semibold text-foreground text-sm">{domain.title}</h3>
                      </CardContent>
                    </Card>
                  </motion.div>
                )
              })}
            </div>
          </div>
        </section>

        {/* Navigation */}
        <section className="py-12 bg-background border-t border-border">
          <div className="container mx-auto px-4">
            <div className="flex flex-col sm:flex-row items-center justify-between gap-4">
              <Button asChild variant="outline" className="group">
                <Link href="/">
                  <Home className="ml-2 h-4 w-4" />
                  العودة للرئيسية
                </Link>
              </Button>
              <div className="flex items-center gap-4">
                <Button asChild variant="outline" className="group">
                  <Link href="/timeline">
                    <ChevronLeft className="ml-2 h-4 w-4 rotate-180" />
                    الجدول الزمني
                  </Link>
                </Button>
                <Button asChild className="group">
                  <Link href="/market-analysis">
                    التحليل الاستراتيجي
                    <ChevronLeft className="mr-2 h-4 w-4" />
                  </Link>
                </Button>
              </div>
            </div>
          </div>
        </section>
      </main>

      <Footer />
    </div>
  )
}
