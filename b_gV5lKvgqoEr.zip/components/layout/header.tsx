"use client"

import { useState, useEffect } from "react"
import Link from "next/link"
import Image from "next/image"
import { usePathname } from "next/navigation"
import { motion, AnimatePresence } from "framer-motion"
import {
  Menu,
  X,
  Mail,
  Phone,
  ChevronDown,
  Globe,
  Facebook,
  Twitter,
  Linkedin,
  Shield,
  MapPin,
} from "lucide-react"
import { cn } from "@/lib/utils"
import { Button } from "@/components/ui/button"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import {
  Sheet,
  SheetContent,
  SheetTrigger,
  SheetClose,
} from "@/components/ui/sheet"
import { navigation } from "@/lib/data"
import { NewsTicker } from "./news-ticker"

const menuGroups = [
  {
    title: "حول المشروع",
    items: [
      { name: "مقدمة", href: "/introduction" },
      { name: "فكرة المشروع", href: "/problem" },
      { name: "الحل المقترح", href: "/solution" },
      { name: "كيف تعالج نوران المشكلة", href: "/how-it-works" },
    ],
  },
  {
    title: "القيم والفريق",
    items: [
      { name: "القيم", href: "/values" },
      { name: "فريق العمل", href: "/team" },
      { name: "الأهداف", href: "/objectives" },
      { name: "الجدول الزمني", href: "/timeline" },
    ],
  },
  {
    title: "الابتكار والاستراتيجية",
    items: [
      { name: "الجوانب الابتكارية", href: "/innovation" },
      { name: "التحليل الاستراتيجي", href: "/market-analysis" },
      { name: "استراتيجية التسويق", href: "/marketing" },
      { name: "خطة الإنتاج", href: "/production" },
    ],
  },
  {
    title: "المالية والعملاء",
    items: [
      { name: "الخطة المالية", href: "/financial" },
      { name: "شرائح العملاء", href: "/customers" },
    ],
  },
  {
    title: "الموارد",
    items: [
      { name: "المقالات", href: "/articles" },
      { name: "الخدمات", href: "/services" },
      { name: "الوثائق", href: "/documents" },
      { name: "الأسئلة الشائعة", href: "/faq" },
    ],
  },
]

export function Header() {
  const [isScrolled, setIsScrolled] = useState(false)
  const [activeGroup, setActiveGroup] = useState<string | null>(null)
  const pathname = usePathname()

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 20)
    }
    window.addEventListener("scroll", handleScroll)
    return () => window.removeEventListener("scroll", handleScroll)
  }, [])

  return (
    <header className="sticky top-0 z-50">
      {/* News Ticker */}
      <NewsTicker />
      
      {/* Top Bar */}
      <div className="bg-primary text-primary-foreground">
        <div className="container mx-auto px-4">
          <div className="flex items-center justify-between h-10 text-sm">
            <div className="flex items-center gap-6">
              <a
                href="mailto:moh_esp@yahoo.fr"
                className="flex items-center gap-2 hover:text-accent transition-colors"
              >
                <Mail className="h-4 w-4" />
                <span className="hidden sm:inline">moh_esp@yahoo.fr</span>
              </a>
              <a
                href="tel:+213661280110"
                className="flex items-center gap-2 hover:text-accent transition-colors"
              >
                <Phone className="h-4 w-4" />
                <span className="hidden sm:inline">0661280110</span>
              </a>
              <a
                href="https://maps.app.goo.gl/ZQaH9KmQKB4k8ayZA?g_st=aw"
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-2 hover:text-accent transition-colors"
              >
                <MapPin className="h-4 w-4" />
                <span className="hidden sm:inline">الموقع</span>
              </a>
            </div>
            <div className="flex items-center gap-4">
              <div className="flex items-center gap-2">
                <a
                  href="#"
                  className="hover:text-accent transition-colors"
                  aria-label="Facebook"
                >
                  <Facebook className="h-4 w-4" />
                </a>
                <a
                  href="#"
                  className="hover:text-accent transition-colors"
                  aria-label="Twitter"
                >
                  <Twitter className="h-4 w-4" />
                </a>
                <a
                  href="#"
                  className="hover:text-accent transition-colors"
                  aria-label="LinkedIn"
                >
                  <Linkedin className="h-4 w-4" />
                </a>
              </div>
              <div className="h-4 w-px bg-primary-foreground/30" />
              <DropdownMenu>
                <DropdownMenuTrigger className="flex items-center gap-1 hover:text-accent transition-colors">
                  <Globe className="h-4 w-4" />
                  <span>العربية</span>
                  <ChevronDown className="h-3 w-3" />
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end">
                  <DropdownMenuItem>العربية</DropdownMenuItem>
                  <DropdownMenuItem>Français</DropdownMenuItem>
                  <DropdownMenuItem>English</DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            </div>
          </div>
        </div>
      </div>

      {/* Main Header */}
      <div
        className={cn(
          "bg-background border-b border-border transition-all duration-300",
          isScrolled && "shadow-lg"
        )}
      >
        <div className="container mx-auto px-4">
          <div className="flex items-center justify-between h-20">
            {/* Logo */}
            <Link href="/" className="flex items-center gap-3 group">
              <div className="relative w-14 h-14 rounded-lg overflow-hidden shadow-lg group-hover:shadow-xl transition-shadow">
                <Image
                  src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/1777042234066-DUchF5f3SaoIl45GB3sM8ouvdvhPY0.jpg"
                  alt="نوران"
                  fill
                  className="object-cover"
                  loading="eager"
                  priority
                />
              </div>
              <div className="flex flex-col">
                <span className="text-xl font-bold text-primary">
                  نوران
                </span>
                <span className="text-sm text-muted-foreground">
                  للوقاية من الفساد
                </span>
              </div>
            </Link>

            {/* Desktop Navigation */}
            <nav className="hidden lg:flex items-center gap-1">
              <Link
                href="/"
                className={cn(
                  "px-4 py-2 text-sm font-medium rounded-md transition-colors",
                  pathname === "/"
                    ? "bg-primary/10 text-primary"
                    : "text-foreground hover:bg-muted hover:text-primary"
                )}
              >
                الرئيسية
              </Link>

              {menuGroups.map((group) => (
                <DropdownMenu
                  key={group.title}
                  open={activeGroup === group.title}
                  onOpenChange={(open) =>
                    setActiveGroup(open ? group.title : null)
                  }
                >
                  <DropdownMenuTrigger
                    className={cn(
                      "flex items-center gap-1 px-4 py-2 text-sm font-medium rounded-md transition-colors",
                      group.items.some((item) => pathname === item.href)
                        ? "bg-primary/10 text-primary"
                        : "text-foreground hover:bg-muted hover:text-primary"
                    )}
                  >
                    {group.title}
                    <ChevronDown className="h-3 w-3" />
                  </DropdownMenuTrigger>
                  <DropdownMenuContent align="start" className="w-56">
                    {group.items.map((item) => (
                      <DropdownMenuItem key={item.href} asChild>
                        <Link
                          href={item.href}
                          className={cn(
                            pathname === item.href && "bg-primary/10 text-primary"
                          )}
                        >
                          {item.name}
                        </Link>
                      </DropdownMenuItem>
                    ))}
                  </DropdownMenuContent>
                </DropdownMenu>
              ))}

              <Link
                href="/contact"
                className={cn(
                  "px-4 py-2 text-sm font-medium rounded-md transition-colors",
                  pathname === "/contact"
                    ? "bg-primary/10 text-primary"
                    : "text-foreground hover:bg-muted hover:text-primary"
                )}
              >
                اتصل بنا
              </Link>
            </nav>

            {/* CTA Button */}
            <div className="hidden lg:flex items-center gap-4">
              <Button asChild className="bg-accent hover:bg-accent/90 text-accent-foreground">
                <Link href="/services">
                  اكتشف الخدمات
                </Link>
              </Button>
            </div>

            {/* Mobile Menu */}
            <Sheet>
              <SheetTrigger asChild className="lg:hidden">
                <Button variant="ghost" size="icon">
                  <Menu className="h-6 w-6" />
                  <span className="sr-only">فتح القائمة</span>
                </Button>
              </SheetTrigger>
              <SheetContent side="right" className="w-[300px] sm:w-[350px] overflow-y-auto">
                <div className="flex flex-col gap-6 py-6">
                  <div className="flex items-center gap-3">
                    <div className="relative w-12 h-12 rounded-lg overflow-hidden">
                      <Image
                        src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/1777042234066-DUchF5f3SaoIl45GB3sM8ouvdvhPY0.jpg"
                        alt="نوران"
                        fill
                        className="object-cover"
                      />
                    </div>
                    <div className="flex flex-col">
                      <span className="text-lg font-bold text-primary">نوران</span>
                      <span className="text-xs text-muted-foreground">للوقاية من الفساد</span>
                    </div>
                  </div>

                  <nav className="flex flex-col gap-2">
                    <SheetClose asChild>
                      <Link
                        href="/"
                        className={cn(
                          "px-4 py-3 text-sm font-medium rounded-md transition-colors",
                          pathname === "/"
                            ? "bg-primary/10 text-primary"
                            : "text-foreground hover:bg-muted"
                        )}
                      >
                        الرئيسية
                      </Link>
                    </SheetClose>

                    {menuGroups.map((group) => (
                      <div key={group.title} className="space-y-1">
                        <div className="px-4 py-2 text-xs font-semibold text-muted-foreground uppercase tracking-wider">
                          {group.title}
                        </div>
                        {group.items.map((item) => (
                          <SheetClose key={item.href} asChild>
                            <Link
                              href={item.href}
                              className={cn(
                                "block px-4 py-2 text-sm font-medium rounded-md transition-colors mr-2",
                                pathname === item.href
                                  ? "bg-primary/10 text-primary"
                                  : "text-foreground hover:bg-muted"
                              )}
                            >
                              {item.name}
                            </Link>
                          </SheetClose>
                        ))}
                      </div>
                    ))}

                    <SheetClose asChild>
                      <Link
                        href="/contact"
                        className={cn(
                          "px-4 py-3 text-sm font-medium rounded-md transition-colors",
                          pathname === "/contact"
                            ? "bg-primary/10 text-primary"
                            : "text-foreground hover:bg-muted"
                        )}
                      >
                        اتصل بنا
                      </Link>
                    </SheetClose>
                  </nav>

                  <div className="pt-4 border-t">
                    <SheetClose asChild>
                      <Button asChild className="w-full bg-accent hover:bg-accent/90 text-accent-foreground">
                        <Link href="/services">اكتشف الخدمات</Link>
                      </Button>
                    </SheetClose>
                  </div>
                </div>
              </SheetContent>
            </Sheet>
          </div>
        </div>
      </div>
    </header>
  )
}
