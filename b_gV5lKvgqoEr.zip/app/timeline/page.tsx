"use client"

import Link from "next/link"
import { motion } from "framer-motion"
import {
  ChevronLeft,
  Clock,
  CheckCircle2,
  Circle,
  Home,
  Calendar,
  Loader2,
} from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Header } from "@/components/layout/header"
import { Footer } from "@/components/layout/footer"
import { PageHero } from "@/components/ui/page-hero"
import { timeline } from "@/lib/data"
import { cn } from "@/lib/utils"

export default function TimelinePage() {
  return (
    <div className="min-h-screen flex flex-col">
      <Header />

      <main className="flex-1">
        <PageHero
          title={timeline.title}
          subtitle={timeline.subtitle}
          description="المراحل الزمنية لتنفيذ مشروع منصة نوران من الإعداد إلى التشغيل"
          breadcrumbs={[
            { label: "الرئيسية", href: "/" },
            { label: "الجدول الزمني", href: "/timeline" },
          ]}
        />

        <section className="py-16 md:py-24 bg-background">
          <div className="container mx-auto px-4">
            <div className="max-w-5xl mx-auto">
              {/* Timeline */}
              <div className="relative">
                {/* Timeline Line */}
                <div className="absolute top-0 bottom-0 right-8 md:right-1/2 w-0.5 bg-border" />

                {timeline.phases.map((phase, index) => {
                  const isCompleted = phase.status === "completed"
                  const isInProgress = phase.status === "in-progress"
                  const isPending = phase.status === "pending"

                  return (
                    <motion.div
                      key={index}
                      initial={{ opacity: 0, y: 20 }}
                      whileInView={{ opacity: 1, y: 0 }}
                      viewport={{ once: true }}
                      transition={{ duration: 0.5, delay: index * 0.15 }}
                      className={cn(
                        "relative mb-12 md:mb-16",
                        index % 2 === 0 ? "md:pr-[calc(50%+2rem)]" : "md:pl-[calc(50%+2rem)] md:text-left"
                      )}
                    >
                      {/* Timeline Dot */}
                      <div
                        className={cn(
                          "absolute right-6 md:right-1/2 md:-translate-x-1/2 w-4 h-4 rounded-full border-4 bg-background z-10",
                          isCompleted && "border-primary bg-primary",
                          isInProgress && "border-accent bg-accent",
                          isPending && "border-muted-foreground"
                        )}
                      />

                      <Card className={cn(
                        "mr-16 md:mr-0 hover:shadow-xl transition-all duration-300",
                        isCompleted && "border-primary/30",
                        isInProgress && "border-accent/50 shadow-lg"
                      )}>
                        <CardContent className="p-6 md:p-8">
                          {/* Status Badge */}
                          <div className="flex items-center gap-2 mb-4">
                            {isCompleted && (
                              <span className="inline-flex items-center gap-1 text-xs font-medium text-primary bg-primary/10 px-3 py-1 rounded-full">
                                <CheckCircle2 className="h-3 w-3" />
                                مكتمل
                              </span>
                            )}
                            {isInProgress && (
                              <span className="inline-flex items-center gap-1 text-xs font-medium text-accent bg-accent/10 px-3 py-1 rounded-full">
                                <Loader2 className="h-3 w-3 animate-spin" />
                                قيد التنفيذ
                              </span>
                            )}
                            {isPending && (
                              <span className="inline-flex items-center gap-1 text-xs font-medium text-muted-foreground bg-muted px-3 py-1 rounded-full">
                                <Circle className="h-3 w-3" />
                                قادم
                              </span>
                            )}
                          </div>

                          {/* Phase Info */}
                          <div className="mb-4">
                            <p className="text-sm text-accent font-medium mb-1">{phase.title}</p>
                            <h3 className="text-xl font-bold text-foreground mb-2">{phase.name}</h3>
                            <p className="text-muted-foreground">{phase.description}</p>
                          </div>

                          {/* Duration */}
                          <div className="flex items-center gap-2 text-sm text-muted-foreground mb-6">
                            <Clock className="h-4 w-4" />
                            <span>المدة: {phase.duration}</span>
                          </div>

                          {/* Tasks */}
                          <div>
                            <h4 className="text-sm font-semibold text-foreground mb-3">المهام:</h4>
                            <ul className="space-y-2">
                              {phase.tasks.map((task, i) => (
                                <li key={i} className="flex items-start gap-3">
                                  <CheckCircle2 className={cn(
                                    "h-4 w-4 flex-shrink-0 mt-0.5",
                                    isCompleted ? "text-primary" : "text-muted-foreground"
                                  )} />
                                  <span className="text-sm text-muted-foreground">{task}</span>
                                </li>
                              ))}
                            </ul>
                          </div>
                        </CardContent>
                      </Card>
                    </motion.div>
                  )
                })}
              </div>
            </div>
          </div>
        </section>

        {/* Summary */}
        <section className="py-16 bg-muted/30">
          <div className="container mx-auto px-4">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              className="max-w-4xl mx-auto text-center"
            >
              <div className="w-20 h-20 rounded-full bg-primary/10 flex items-center justify-center mx-auto mb-8">
                <Calendar className="h-10 w-10 text-primary" />
              </div>
              <h2 className="text-2xl md:text-3xl font-bold text-foreground mb-6">
                خطة تنفيذ محكمة
              </h2>
              <p className="text-lg text-muted-foreground leading-relaxed">
                يتم تنفيذ مشروع منصة نوران وفق جدول زمني محكم يمتد على 15 شهرًا، مقسمة إلى أربع مراحل رئيسية، مع متابعة مستمرة وتقييم دوري لضمان تحقيق الأهداف المرسومة.
              </p>
            </motion.div>
          </div>
        </section>

        {/* Navigation */}
        <section className="py-12 bg-background border-t border-border">
          <div className="container mx-auto px-4">
            <div className="flex flex-col sm:flex-row items-center justify-between gap-4">
              <Button asChild variant="outline" className="group">
                <Link href="/">
                  <Home className="ml-2 h-4 w-4" />
                  العودة للرئيسية
                </Link>
              </Button>
              <div className="flex items-center gap-4">
                <Button asChild variant="outline" className="group">
                  <Link href="/objectives">
                    <ChevronLeft className="ml-2 h-4 w-4 rotate-180" />
                    الأهداف
                  </Link>
                </Button>
                <Button asChild className="group">
                  <Link href="/innovation">
                    الجوانب الابتكارية
                    <ChevronLeft className="mr-2 h-4 w-4" />
                  </Link>
                </Button>
              </div>
            </div>
          </div>
        </section>
      </main>

      <Footer />
    </div>
  )
}
