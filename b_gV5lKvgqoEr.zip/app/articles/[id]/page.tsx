"use client"

import Link from "next/link"
import { useParams } from "next/navigation"
import { motion } from "framer-motion"
import {
  ArrowLeft,
  ChevronLeft,
  Home,
  BookOpen,
  Calendar,
  User,
  Tag,
  Share2,
  Facebook,
  Twitter,
  Linkedin,
} from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Header } from "@/components/layout/header"
import { Footer } from "@/components/layout/footer"
import { articles } from "@/lib/data"

export default function ArticleDetailPage() {
  const params = useParams()
  const articleId = params.id as string
  
  const article = articles.find(a => a.id === articleId)
  const currentIndex = articles.findIndex(a => a.id === articleId)
  const prevArticle = currentIndex > 0 ? articles[currentIndex - 1] : null
  const nextArticle = currentIndex < articles.length - 1 ? articles[currentIndex + 1] : null
  const relatedArticles = articles.filter(a => a.id !== articleId && a.category === article?.category).slice(0, 3)

  if (!article) {
    return (
      <div className="min-h-screen flex flex-col">
        <Header />
        <main className="flex-1 flex items-center justify-center">
          <div className="text-center">
            <h1 className="text-2xl font-bold mb-4">المقال غير موجود</h1>
            <Button asChild>
              <Link href="/articles">العودة للمقالات</Link>
            </Button>
          </div>
        </main>
        <Footer />
      </div>
    )
  }

  return (
    <div className="min-h-screen flex flex-col">
      <Header />

      <main className="flex-1">
        {/* Hero */}
        <section className="relative py-20 bg-gradient-to-bl from-primary via-primary to-primary/95 text-primary-foreground">
          <div className="absolute inset-0 opacity-10">
            <div
              className="absolute inset-0"
              style={{
                backgroundImage: `url("data:image/svg+xml,%3Csvg width='60' height='60' viewBox='0 0 60 60' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='none' fill-rule='evenodd'%3E%3Cg fill='%23ffffff' fill-opacity='0.4'%3E%3Cpath d='M36 34v-4h-2v4h-4v2h4v4h2v-4h4v-2h-4zm0-30V0h-2v4h-4v2h4v4h2V6h4V4h-4zM6 34v-4H4v4H0v2h4v4h2v-4h4v-2H6zM6 4V0H4v4H0v2h4v4h2V6h4V4H6z'/%3E%3C/g%3E%3C/g%3E%3C/svg%3E")`,
              }}
            />
          </div>
          <div className="container mx-auto px-4 relative z-10">
            {/* Breadcrumbs */}
            <nav className="mb-8">
              <ol className="flex items-center gap-2 text-sm text-primary-foreground/70">
                <li>
                  <Link href="/" className="hover:text-primary-foreground transition-colors flex items-center gap-1">
                    <Home className="h-4 w-4" />
                    الرئيسية
                  </Link>
                </li>
                <li><ChevronLeft className="h-4 w-4" /></li>
                <li>
                  <Link href="/articles" className="hover:text-primary-foreground transition-colors">
                    المقالات
                  </Link>
                </li>
                <li><ChevronLeft className="h-4 w-4" /></li>
                <li className="text-primary-foreground font-medium truncate max-w-[200px]">
                  {article.title}
                </li>
              </ol>
            </nav>

            <div className="max-w-4xl">
              {/* Category & Date */}
              <div className="flex items-center gap-4 mb-6">
                <span className="inline-flex items-center gap-2 bg-accent text-accent-foreground text-sm font-medium px-4 py-1.5 rounded-full">
                  <Tag className="h-4 w-4" />
                  {article.category}
                </span>
                <span className="flex items-center gap-2 text-primary-foreground/80">
                  <Calendar className="h-4 w-4" />
                  {new Date(article.date).toLocaleDateString("ar-MA", {
                    year: "numeric",
                    month: "long",
                    day: "numeric",
                  })}
                </span>
              </div>

              {/* Title */}
              <h1 className="text-3xl md:text-4xl lg:text-5xl font-bold mb-6 leading-tight">
                {article.title}
              </h1>

              {/* Author */}
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 rounded-full bg-white/20 flex items-center justify-center">
                  <User className="h-6 w-6" />
                </div>
                <div>
                  <p className="font-medium">{article.author}</p>
                  <p className="text-sm text-primary-foreground/70">كاتب المقال</p>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Article Content */}
        <section className="py-16 bg-background">
          <div className="container mx-auto px-4">
            <div className="max-w-4xl mx-auto">
              {/* Featured Image */}
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                className="aspect-video bg-gradient-to-br from-primary/20 to-accent/20 rounded-2xl mb-12 overflow-hidden"
              >
                {article.image ? (
                  <img
                    src={article.image}
                    alt={article.title}
                    className="w-full h-full object-cover"
                  />
                ) : (
                  <div className="w-full h-full flex items-center justify-center">
                    <BookOpen className="h-24 w-24 text-primary/30" />
                  </div>
                )}
              </motion.div>

              {/* Content */}
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                className="prose prose-lg max-w-none"
              >
                <div className="text-lg text-muted-foreground leading-relaxed whitespace-pre-line">
                  {article.content}
                </div>
              </motion.div>

              {/* Share */}
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                className="mt-12 pt-8 border-t border-border"
              >
                <div className="flex items-center justify-between flex-wrap gap-4">
                  <div className="flex items-center gap-3">
                    <span className="text-sm font-medium text-muted-foreground">مشاركة:</span>
                    <div className="flex items-center gap-2">
                      <Button variant="outline" size="icon" className="rounded-full">
                        <Facebook className="h-4 w-4" />
                      </Button>
                      <Button variant="outline" size="icon" className="rounded-full">
                        <Twitter className="h-4 w-4" />
                      </Button>
                      <Button variant="outline" size="icon" className="rounded-full">
                        <Linkedin className="h-4 w-4" />
                      </Button>
                      <Button variant="outline" size="icon" className="rounded-full">
                        <Share2 className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                  <Link
                    href={`/categories/${article.category}`}
                    className="inline-flex items-center gap-2 text-primary hover:underline"
                  >
                    <Tag className="h-4 w-4" />
                    المزيد من مقالات {article.category}
                  </Link>
                </div>
              </motion.div>
            </div>
          </div>
        </section>

        {/* Related Articles */}
        {relatedArticles.length > 0 && (
          <section className="py-16 bg-muted/30">
            <div className="container mx-auto px-4">
              <h2 className="text-2xl font-bold text-foreground mb-8 text-center">
                مقالات ذات صلة
              </h2>
              <div className="grid md:grid-cols-3 gap-6 max-w-5xl mx-auto">
                {relatedArticles.map((relatedArticle, index) => (
                  <motion.div
                    key={relatedArticle.id}
                    initial={{ opacity: 0, y: 20 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    viewport={{ once: true }}
                    transition={{ duration: 0.5, delay: index * 0.1 }}
                  >
                    <Link href={`/articles/${relatedArticle.id}`} className="block group">
                      <Card className="h-full hover:shadow-lg hover:border-primary/30 transition-all">
                        <CardContent className="p-6">
                          <div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center mb-4">
                            <BookOpen className="h-6 w-6 text-primary" />
                          </div>
                          <h3 className="font-bold text-foreground mb-2 group-hover:text-primary transition-colors line-clamp-2">
                            {relatedArticle.title}
                          </h3>
                          <p className="text-sm text-muted-foreground line-clamp-2">
                            {relatedArticle.excerpt}
                          </p>
                        </CardContent>
                      </Card>
                    </Link>
                  </motion.div>
                ))}
              </div>
            </div>
          </section>
        )}

        {/* Navigation */}
        <section className="py-12 bg-background border-t border-border">
          <div className="container mx-auto px-4">
            <div className="flex flex-col sm:flex-row items-center justify-between gap-4">
              <Button asChild variant="outline" className="group">
                <Link href="/articles">
                  <ArrowLeft className="ml-2 h-4 w-4 rotate-180" />
                  جميع المقالات
                </Link>
              </Button>
              <div className="flex items-center gap-4">
                {prevArticle && (
                  <Button asChild variant="outline" className="group">
                    <Link href={`/articles/${prevArticle.id}`}>
                      <ChevronLeft className="ml-2 h-4 w-4 rotate-180" />
                      السابق
                    </Link>
                  </Button>
                )}
                {nextArticle && (
                  <Button asChild className="group">
                    <Link href={`/articles/${nextArticle.id}`}>
                      التالي
                      <ChevronLeft className="mr-2 h-4 w-4" />
                    </Link>
                  </Button>
                )}
              </div>
            </div>
          </div>
        </section>
      </main>

      <Footer />
    </div>
  )
}
