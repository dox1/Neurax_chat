"use client"

import { useState } from "react"
import Link from "next/link"
import { motion, AnimatePresence } from "framer-motion"
import {
  ArrowLeft,
  ArrowRight,
  BookOpen,
  AlertOctagon,
  Brain,
  BarChart3,
  Shield,
  LineChart,
  ChevronDown,
  Route,
  BarChart,
  Bell,
  MessageCircle,
  Eye,
  Target,
} from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Header } from "@/components/layout/header"
import { Footer } from "@/components/layout/footer"
import { PageHero } from "@/components/ui/page-hero"
import { howItWorks } from "@/lib/data"

const iconMap: Record<string, React.ComponentType<{ className?: string }>> = {
  BookOpen,
  AlertOctagon,
  Brain,
  BarChart3,
  Shield,
  LineChart,
  Route,
  BarChart,
  Bell,
  MessageCircle,
  Eye,
  Target,
}

export default function HowItWorksPage() {
  const [expandedMechanism, setExpandedMechanism] = useState<number | null>(null)

  return (
    <div className="min-h-screen flex flex-col">
      <Header />

      <main className="flex-1">
        <PageHero
          title={howItWorks.title}
          subtitle={howItWorks.subtitle}
          description="تعرف على الآليات والأدوات التي توفرها منصة نوران لمعالجة تحديات الفساد في الصفقات العمومية"
          breadcrumbs={[{ label: "كيف تعالج نوران المشكلة" }]}
        />

        {/* Mechanisms Section */}
        <section className="py-16 md:py-24 bg-background">
          <div className="container mx-auto px-4">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
              className="text-center mb-16"
            >
              <h2 className="text-2xl md:text-3xl font-bold text-foreground mb-4">
                الآليات الرئيسية
              </h2>
              <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
                اضغط على أي آلية لعرض التفاصيل الكاملة
              </p>
            </motion.div>

            <div className="max-w-4xl mx-auto space-y-4">
              {howItWorks.mechanisms.map((mechanism, index) => {
                const IconComponent = iconMap[mechanism.icon] || Shield
                const isExpanded = expandedMechanism === index

                return (
                  <motion.div
                    key={index}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.5, delay: index * 0.1 }}
                  >
                    <Card
                      className={`border-border/50 overflow-hidden transition-all cursor-pointer ${
                        isExpanded ? "border-primary/50 shadow-lg" : "hover:border-primary/30"
                      }`}
                      onClick={() => setExpandedMechanism(isExpanded ? null : index)}
                    >
                      <CardHeader className="pb-4">
                        <div className="flex items-start justify-between">
                          <div className="flex items-start gap-4">
                            <div className={`w-14 h-14 rounded-xl flex items-center justify-center flex-shrink-0 transition-colors ${
                              isExpanded ? "bg-primary text-primary-foreground" : "bg-primary/10"
                            }`}>
                              <IconComponent className={`h-7 w-7 ${isExpanded ? "text-primary-foreground" : "text-primary"}`} />
                            </div>
                            <div>
                              <CardTitle className="text-lg mb-2">{mechanism.title}</CardTitle>
                              <CardDescription className="text-base">
                                {mechanism.description}
                              </CardDescription>
                            </div>
                          </div>
                          <ChevronDown
                            className={`h-5 w-5 text-muted-foreground transition-transform ${
                              isExpanded ? "rotate-180" : ""
                            }`}
                          />
                        </div>
                      </CardHeader>

                      <AnimatePresence>
                        {isExpanded && (
                          <motion.div
                            initial={{ height: 0, opacity: 0 }}
                            animate={{ height: "auto", opacity: 1 }}
                            exit={{ height: 0, opacity: 0 }}
                            transition={{ duration: 0.3 }}
                          >
                            <CardContent className="pt-0 pb-6 border-t border-border/50 mt-2">
                              <div className="pt-6">
                                <h4 className="font-semibold text-foreground mb-4">
                                  المكونات الرئيسية:
                                </h4>
                                <ul className="grid md:grid-cols-2 gap-3">
                                  {mechanism.details.map((detail, detailIndex) => (
                                    <li
                                      key={detailIndex}
                                      className="flex items-center gap-3 bg-muted/50 rounded-lg p-3"
                                    >
                                      <div className="w-2 h-2 rounded-full bg-primary" />
                                      <span className="text-foreground/90">{detail}</span>
                                    </li>
                                  ))}
                                </ul>
                              </div>
                            </CardContent>
                          </motion.div>
                        )}
                      </AnimatePresence>
                    </Card>
                  </motion.div>
                )
              })}
            </div>
          </div>
        </section>

        {/* Sub Elements */}
        <section className="py-16 md:py-24 bg-muted/30">
          <div className="container mx-auto px-4">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              className="text-center mb-12"
            >
              <h2 className="text-2xl md:text-3xl font-bold text-foreground mb-4">
                العناصر الأساسية
              </h2>
              <p className="text-lg text-muted-foreground">
                المكونات الرئيسية لمنظومة نوران
              </p>
            </motion.div>

            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
              {howItWorks.subElements.map((element, index) => {
                const IconComponent = iconMap[element.icon] || Target
                return (
                  <motion.div
                    key={index}
                    initial={{ opacity: 0, scale: 0.9 }}
                    whileInView={{ opacity: 1, scale: 1 }}
                    viewport={{ once: true }}
                    transition={{ duration: 0.5, delay: index * 0.1 }}
                  >
                    <Card className="h-full text-center hover:shadow-lg hover:border-primary/30 transition-all card-hover">
                      <CardContent className="p-6">
                        <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center mx-auto mb-4">
                          <IconComponent className="h-6 w-6 text-primary" />
                        </div>
                        <h3 className="font-semibold text-foreground mb-2">{element.title}</h3>
                        <p className="text-sm text-muted-foreground">{element.description}</p>
                      </CardContent>
                    </Card>
                  </motion.div>
                )
              })}
            </div>
          </div>
        </section>

        {/* CTA */}
        <section className="py-16 bg-primary text-primary-foreground">
          <div className="container mx-auto px-4">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              className="max-w-3xl mx-auto text-center"
            >
              <h2 className="text-2xl md:text-3xl font-bold mb-6">
                اكتشف خدماتنا المتكاملة
              </h2>
              <p className="text-lg text-primary-foreground/90 mb-8">
                تعرف على الخدمات التي توفرها منصة نوران لدعم جهود مكافحة الفساد وتعزيز الشفافية
              </p>
              <Button
                asChild
                size="lg"
                className="bg-accent hover:bg-accent/90 text-accent-foreground group"
              >
                <Link href="/services">
                  استكشف الخدمات
                  <ArrowLeft className="mr-2 h-4 w-4 group-hover:-translate-x-1 transition-transform" />
                </Link>
              </Button>
            </motion.div>
          </div>
        </section>

        {/* Navigation */}
        <section className="py-8 bg-background border-t border-border">
          <div className="container mx-auto px-4">
            <div className="flex items-center justify-between">
              <Button asChild variant="ghost" className="group">
                <Link href="/solution">
                  <ArrowRight className="ml-2 h-4 w-4 group-hover:translate-x-1 transition-transform" />
                  الحل المقترح
                </Link>
              </Button>
              <Button asChild className="group">
                <Link href="/values">
                  القيم
                  <ArrowLeft className="mr-2 h-4 w-4 group-hover:-translate-x-1 transition-transform" />
                </Link>
              </Button>
            </div>
          </div>
        </section>
      </main>

      <Footer />
    </div>
  )
}
