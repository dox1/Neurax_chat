"use client"

import Link from "next/link"
import { ArrowLeft } from "lucide-react"
import { cn } from "@/lib/utils"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import * as LucideIcons from "lucide-react"

interface SectionCardProps {
  title: string
  description: string
  href: string
  icon?: string
  className?: string
  variant?: "default" | "featured" | "compact"
}

export function SectionCard({
  title,
  description,
  href,
  icon,
  className,
  variant = "default",
}: SectionCardProps) {
  const IconComponent = icon ? (LucideIcons as Record<string, React.ComponentType<{ className?: string }>>)[icon] : null

  if (variant === "compact") {
    return (
      <Link href={href} className="block group">
        <Card className={cn(
          "h-full border-border/50 hover:border-primary/30 hover:shadow-lg transition-all duration-300 group-hover:-translate-y-1",
          className
        )}>
          <CardContent className="p-6">
            <div className="flex items-start gap-4">
              {IconComponent && (
                <div className="w-12 h-12 rounded-lg bg-primary/10 flex items-center justify-center flex-shrink-0 group-hover:bg-primary group-hover:text-primary-foreground transition-colors">
                  <IconComponent className="h-6 w-6 text-primary group-hover:text-primary-foreground transition-colors" />
                </div>
              )}
              <div className="flex-1 min-w-0">
                <h3 className="font-semibold text-foreground mb-2 group-hover:text-primary transition-colors">
                  {title}
                </h3>
                <p className="text-sm text-muted-foreground line-clamp-2">
                  {description}
                </p>
              </div>
              <ArrowLeft className="h-5 w-5 text-muted-foreground group-hover:text-primary transition-colors flex-shrink-0 mt-1" />
            </div>
          </CardContent>
        </Card>
      </Link>
    )
  }

  if (variant === "featured") {
    return (
      <Card className={cn(
        "h-full border-border/50 hover:border-accent/50 hover:shadow-xl transition-all duration-300 overflow-hidden group",
        className
      )}>
        <div className="absolute top-0 left-0 right-0 h-1 bg-gradient-to-r from-primary via-accent to-primary" />
        <CardHeader className="pb-4">
          {IconComponent && (
            <div className="w-16 h-16 rounded-xl bg-gradient-to-br from-primary to-primary/80 flex items-center justify-center mb-4 group-hover:scale-110 transition-transform">
              <IconComponent className="h-8 w-8 text-primary-foreground" />
            </div>
          )}
          <CardTitle className="text-xl group-hover:text-primary transition-colors">
            {title}
          </CardTitle>
        </CardHeader>
        <CardContent className="pt-0">
          <CardDescription className="text-base mb-6 line-clamp-3">
            {description}
          </CardDescription>
          <Button asChild variant="outline" className="group/btn">
            <Link href={href}>
              <span>عرض التفاصيل</span>
              <ArrowLeft className="h-4 w-4 mr-2 group-hover/btn:-translate-x-1 transition-transform" />
            </Link>
          </Button>
        </CardContent>
      </Card>
    )
  }

  return (
    <Card className={cn(
      "h-full border-border/50 hover:border-primary/30 hover:shadow-lg transition-all duration-300 card-hover",
      className
    )}>
      <CardHeader className="pb-4">
        {IconComponent && (
          <div className="w-14 h-14 rounded-lg bg-primary/10 flex items-center justify-center mb-4">
            <IconComponent className="h-7 w-7 text-primary" />
          </div>
        )}
        <CardTitle className="text-lg">{title}</CardTitle>
      </CardHeader>
      <CardContent className="pt-0">
        <CardDescription className="mb-6 line-clamp-3">
          {description}
        </CardDescription>
        <Button asChild variant="ghost" className="p-0 h-auto text-primary hover:text-primary/80 group/btn">
          <Link href={href}>
            <span>عرض المزيد</span>
            <ArrowLeft className="h-4 w-4 mr-2 group-hover/btn:-translate-x-1 transition-transform" />
          </Link>
        </Button>
      </CardContent>
    </Card>
  )
}
