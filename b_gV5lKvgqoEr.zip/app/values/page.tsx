"use client"

import Link from "next/link"
import { motion } from "framer-motion"
import {
  ArrowLeft,
  ChevronLeft,
  GraduationCap,
  Heart,
  Eye,
  Scale,
  ShieldCheck,
  Equal,
  UserCheck,
  Users,
  Lightbulb,
  BadgeCheck,
  Home,
} from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Header } from "@/components/layout/header"
import { Footer } from "@/components/layout/footer"
import { PageHero } from "@/components/ui/page-hero"
import { values } from "@/lib/data"

const iconMap: Record<string, React.ComponentType<{ className?: string }>> = {
  GraduationCap,
  Heart,
  Eye,
  Scale,
  ShieldCheck,
  Equal,
  UserCheck,
  Users,
  Lightbulb,
  BadgeCheck,
}

export default function ValuesPage() {
  return (
    <div className="min-h-screen flex flex-col">
      <Header />

      <main className="flex-1">
        <PageHero
          title={values.title}
          subtitle={values.subtitle}
          description={values.description}
          breadcrumbs={[
            { label: "الرئيسية", href: "/" },
            { label: "القيم المقترحة", href: "/values" },
          ]}
        />

        <section className="py-16 md:py-24 bg-background">
          <div className="container mx-auto px-4">
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
              {values.items.map((value, index) => {
                const IconComponent = iconMap[value.icon] || Heart
                return (
                  <motion.div
                    key={index}
                    initial={{ opacity: 0, y: 20 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    viewport={{ once: true }}
                    transition={{ duration: 0.5, delay: index * 0.1 }}
                  >
                    <Card className="h-full hover:shadow-xl hover:border-primary/30 transition-all duration-300 group">
                      <CardContent className="p-8">
                        <div className="w-16 h-16 rounded-xl bg-gradient-to-br from-primary to-primary/80 flex items-center justify-center mb-6 group-hover:scale-110 transition-transform">
                          <IconComponent className="h-8 w-8 text-primary-foreground" />
                        </div>
                        <h3 className="text-xl font-bold text-foreground mb-4 group-hover:text-primary transition-colors">
                          {value.title}
                        </h3>
                        <p className="text-muted-foreground leading-relaxed">
                          {value.description}
                        </p>
                      </CardContent>
                    </Card>
                  </motion.div>
                )
              })}
            </div>
          </div>
        </section>

        {/* Summary Section */}
        <section className="py-16 bg-muted/30">
          <div className="container mx-auto px-4">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              className="max-w-4xl mx-auto text-center"
            >
              <div className="w-20 h-20 rounded-full bg-primary/10 flex items-center justify-center mx-auto mb-8">
                <ShieldCheck className="h-10 w-10 text-primary" />
              </div>
              <h2 className="text-2xl md:text-3xl font-bold text-foreground mb-6">
                قيم راسخة لبناء منصة موثوقة
              </h2>
              <p className="text-lg text-muted-foreground leading-relaxed">
                تشكل هذه القيم الأساس الأخلاقي والمهني الذي تقوم عليه منصة نوران، وهي ليست مجرد شعارات بل التزامات عملية تنعكس في كل جانب من جوانب عمل المنصة وخدماتها.
              </p>
            </motion.div>
          </div>
        </section>

        {/* Navigation */}
        <section className="py-12 bg-background border-t border-border">
          <div className="container mx-auto px-4">
            <div className="flex flex-col sm:flex-row items-center justify-between gap-4">
              <Button asChild variant="outline" className="group">
                <Link href="/">
                  <Home className="ml-2 h-4 w-4" />
                  العودة للرئيسية
                </Link>
              </Button>
              <div className="flex items-center gap-4">
                <Button asChild variant="outline" className="group">
                  <Link href="/solution">
                    <ChevronLeft className="ml-2 h-4 w-4 rotate-180" />
                    الحل المقترح
                  </Link>
                </Button>
                <Button asChild className="group">
                  <Link href="/team">
                    فريق العمل
                    <ChevronLeft className="mr-2 h-4 w-4" />
                  </Link>
                </Button>
              </div>
            </div>
          </div>
        </section>
      </main>

      <Footer />
    </div>
  )
}
