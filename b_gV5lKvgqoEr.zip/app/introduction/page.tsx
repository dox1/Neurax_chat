"use client"

import Link from "next/link"
import { motion } from "framer-motion"
import { ArrowLeft, ArrowRight, CheckCircle2, AlertTriangle } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Header } from "@/components/layout/header"
import { Footer } from "@/components/layout/footer"
import { PageHero } from "@/components/ui/page-hero"
import { introduction } from "@/lib/data"

export default function IntroductionPage() {
  return (
    <div className="min-h-screen flex flex-col">
      <Header />

      <main className="flex-1">
        <PageHero
          title={introduction.title}
          subtitle={introduction.subtitle}
          description="تعرف على السياق العام لمنصة نوران والتحديات التي تواجه قطاع الصفقات العمومية"
          breadcrumbs={[{ label: "مقدمة" }]}
        />

        {/* Main Content */}
        <section className="py-16 md:py-24 bg-background">
          <div className="container mx-auto px-4">
            <div className="max-w-4xl mx-auto">
              {/* Content */}
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5 }}
                className="prose prose-lg max-w-none"
              >
                {introduction.content.split("\n\n").map((paragraph, index) => (
                  <p
                    key={index}
                    className="text-foreground/90 leading-relaxed mb-6 text-lg"
                  >
                    {paragraph}
                  </p>
                ))}
              </motion.div>

              {/* Key Points */}
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: 0.2 }}
                className="mt-12"
              >
                <h2 className="text-2xl font-bold text-foreground mb-8">
                  التحديات الرئيسية في قطاع الصفقات العمومية
                </h2>
                <div className="grid md:grid-cols-2 gap-4">
                  {introduction.keyPoints.map((point, index) => (
                    <Card
                      key={index}
                      className="border-border/50 hover:border-primary/30 hover:shadow-md transition-all"
                    >
                      <CardContent className="p-4 flex items-start gap-4">
                        <div className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center flex-shrink-0">
                          <AlertTriangle className="h-4 w-4 text-primary" />
                        </div>
                        <p className="text-foreground/90">{point}</p>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </motion.div>

              {/* Conclusion */}
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: 0.3 }}
                className="mt-12 p-8 bg-primary/5 rounded-2xl border border-primary/20"
              >
                <div className="flex items-start gap-4">
                  <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center flex-shrink-0">
                    <CheckCircle2 className="h-6 w-6 text-primary" />
                  </div>
                  <div>
                    <h3 className="text-xl font-bold text-foreground mb-3">
                      الحل: منصة نوران
                    </h3>
                    <p className="text-foreground/90 leading-relaxed">
                      في هذا السياق، جاءت منصة نوران كحل رقمي مبتكر واستباقي
                      يهدف إلى تعزيز الشفافية والحكامة الجيدة والوقاية المبكرة
                      من جرائم الفساد في الصفقات العمومية، من خلال توظيف
                      التكنولوجيا والبيانات لدعم الرقابة الاستباقية وتسهيل
                      الولوج إلى المعلومات.
                    </p>
                  </div>
                </div>
              </motion.div>

              {/* Navigation */}
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: 0.4 }}
                className="mt-12 flex items-center justify-between pt-8 border-t border-border"
              >
                <Button asChild variant="ghost" className="group">
                  <Link href="/">
                    <ArrowRight className="ml-2 h-4 w-4 group-hover:translate-x-1 transition-transform" />
                    الرئيسية
                  </Link>
                </Button>
                <Button asChild className="group">
                  <Link href="/problem">
                    فكرة المشروع
                    <ArrowLeft className="mr-2 h-4 w-4 group-hover:-translate-x-1 transition-transform" />
                  </Link>
                </Button>
              </motion.div>
            </div>
          </div>
        </section>
      </main>

      <Footer />
    </div>
  )
}
