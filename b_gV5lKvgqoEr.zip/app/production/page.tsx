"use client"

import Link from "next/link"
import { motion } from "framer-motion"
import {
  ChevronLeft,
  CheckCircle2,
  Home,
  Settings,
  Clock,
  AlertTriangle,
  Shield,
  Target,
} from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Header } from "@/components/layout/header"
import { Footer } from "@/components/layout/footer"
import { PageHero } from "@/components/ui/page-hero"
import { productionPlan } from "@/lib/data"

export default function ProductionPage() {
  return (
    <div className="min-h-screen flex flex-col">
      <Header />

      <main className="flex-1">
        <PageHero
          title={productionPlan.title}
          subtitle={productionPlan.subtitle}
          description="منهجية العمل والمراحل التقنية لبناء وتشغيل منصة نوران"
          breadcrumbs={[
            { label: "الرئيسية", href: "/" },
            { label: "خطة الإنتاج", href: "/production" },
          ]}
        />

        {/* Objective */}
        <section className="py-16 bg-primary text-primary-foreground">
          <div className="container mx-auto px-4">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              className="max-w-4xl mx-auto text-center"
            >
              <div className="w-20 h-20 rounded-full bg-white/10 flex items-center justify-center mx-auto mb-8">
                <Target className="h-10 w-10 text-accent" />
              </div>
              <h2 className="text-2xl md:text-3xl font-bold mb-6">
                {productionPlan.objective.title}
              </h2>
              <p className="text-lg text-primary-foreground/90 leading-relaxed">
                {productionPlan.objective.description}
              </p>
            </motion.div>
          </div>
        </section>

        {/* Production Phases */}
        <section className="py-16 md:py-24 bg-background">
          <div className="container mx-auto px-4">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              className="text-center mb-16"
            >
              <h2 className="text-2xl md:text-3xl font-bold text-foreground mb-4">
                مراحل العملية الإنتاجية
              </h2>
            </motion.div>

            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6 max-w-6xl mx-auto">
              {productionPlan.phases.map((phase, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.5, delay: index * 0.1 }}
                >
                  <Card className="h-full hover:shadow-xl hover:border-primary/30 transition-all duration-300 group">
                    <CardHeader>
                      <div className="flex items-center justify-between mb-4">
                        <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-primary to-primary/80 flex items-center justify-center group-hover:scale-110 transition-transform">
                          <span className="text-xl font-bold text-primary-foreground">{index + 1}</span>
                        </div>
                        <div className="flex items-center gap-2 text-sm text-muted-foreground">
                          <Clock className="h-4 w-4" />
                          {phase.duration}
                        </div>
                      </div>
                      <CardTitle className="text-lg group-hover:text-primary transition-colors">
                        {phase.title}
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <ul className="space-y-2">
                        {phase.tasks.map((task, i) => (
                          <li key={i} className="flex items-start gap-2">
                            <CheckCircle2 className="h-4 w-4 text-primary flex-shrink-0 mt-0.5" />
                            <span className="text-sm text-muted-foreground">{task}</span>
                          </li>
                        ))}
                      </ul>
                    </CardContent>
                  </Card>
                </motion.div>
              ))}
            </div>
          </div>
        </section>

        {/* Technical Risks */}
        <section className="py-16 bg-muted/30">
          <div className="container mx-auto px-4">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              className="text-center mb-12"
            >
              <div className="w-16 h-16 rounded-full bg-destructive/10 flex items-center justify-center mx-auto mb-6">
                <AlertTriangle className="h-8 w-8 text-destructive" />
              </div>
              <h2 className="text-2xl md:text-3xl font-bold text-foreground mb-4">
                المخاطر التقنية وسبل المعالجة
              </h2>
            </motion.div>

            <div className="grid md:grid-cols-2 gap-6 max-w-4xl mx-auto">
              {productionPlan.technicalRisks.map((item, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.5, delay: index * 0.1 }}
                >
                  <Card className="h-full hover:shadow-lg transition-shadow">
                    <CardContent className="p-6">
                      <div className="flex items-start gap-4">
                        <div className="w-12 h-12 rounded-xl bg-destructive/10 flex items-center justify-center flex-shrink-0">
                          <AlertTriangle className="h-6 w-6 text-destructive" />
                        </div>
                        <div className="flex-1">
                          <h3 className="font-semibold text-foreground mb-2">{item.risk}</h3>
                          <div className="flex items-start gap-2">
                            <Shield className="h-4 w-4 text-primary flex-shrink-0 mt-1" />
                            <p className="text-sm text-muted-foreground">{item.mitigation}</p>
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </motion.div>
              ))}
            </div>
          </div>
        </section>

        {/* Navigation */}
        <section className="py-12 bg-background border-t border-border">
          <div className="container mx-auto px-4">
            <div className="flex flex-col sm:flex-row items-center justify-between gap-4">
              <Button asChild variant="outline" className="group">
                <Link href="/">
                  <Home className="ml-2 h-4 w-4" />
                  العودة للرئيسية
                </Link>
              </Button>
              <div className="flex items-center gap-4">
                <Button asChild variant="outline" className="group">
                  <Link href="/marketing">
                    <ChevronLeft className="ml-2 h-4 w-4 rotate-180" />
                    استراتيجية التسويق
                  </Link>
                </Button>
                <Button asChild className="group">
                  <Link href="/financial">
                    الخطة المالية
                    <ChevronLeft className="mr-2 h-4 w-4" />
                  </Link>
                </Button>
              </div>
            </div>
          </div>
        </section>
      </main>

      <Footer />
    </div>
  )
}
