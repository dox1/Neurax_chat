"use client"

import Link from "next/link"
import { motion } from "framer-motion"
import {
  ChevronLeft,
  TrendingUp,
  AlertTriangle,
  Target,
  Users,
  CheckCircle2,
  Home,
  BarChart3,
  Building2,
  Globe,
  Shield,
} from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Header } from "@/components/layout/header"
import { Footer } from "@/components/layout/footer"
import { PageHero } from "@/components/ui/page-hero"
import { marketAnalysis } from "@/lib/data"

export default function MarketAnalysisPage() {
  return (
    <div className="min-h-screen flex flex-col">
      <Header />

      <main className="flex-1">
        <PageHero
          title={marketAnalysis.title}
          subtitle={marketAnalysis.subtitle}
          description="تحليل شامل للقطاع والفرص والتحديات والتموقع الاستراتيجي للمشروع"
          breadcrumbs={[
            { label: "الرئيسية", href: "/" },
            { label: "التحليل الاستراتيجي", href: "/market-analysis" },
          ]}
        />

        {/* Sector Overview */}
        <section className="py-16 bg-primary text-primary-foreground">
          <div className="container mx-auto px-4">
            <div className="max-w-4xl mx-auto">
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                className="text-center"
              >
                <div className="w-20 h-20 rounded-full bg-white/10 flex items-center justify-center mx-auto mb-8">
                  <BarChart3 className="h-10 w-10 text-accent" />
                </div>
                <h2 className="text-2xl md:text-3xl font-bold mb-6">
                  {marketAnalysis.sectorOverview.title}
                </h2>
                <p className="text-lg text-primary-foreground/90 leading-relaxed">
                  {marketAnalysis.sectorOverview.description}
                </p>
              </motion.div>
            </div>
          </div>
        </section>

        {/* Sector Definition & Status */}
        <section className="py-16 md:py-24 bg-background">
          <div className="container mx-auto px-4">
            <div className="grid md:grid-cols-2 gap-8 max-w-5xl mx-auto">
              <motion.div
                initial={{ opacity: 0, x: 20 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
              >
                <Card className="h-full hover:shadow-xl transition-shadow">
                  <CardHeader>
                    <div className="w-14 h-14 rounded-xl bg-primary/10 flex items-center justify-center mb-4">
                      <Building2 className="h-7 w-7 text-primary" />
                    </div>
                    <CardTitle>{marketAnalysis.sectorDefinition.title}</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-muted-foreground leading-relaxed">
                      {marketAnalysis.sectorDefinition.content}
                    </p>
                  </CardContent>
                </Card>
              </motion.div>

              <motion.div
                initial={{ opacity: 0, x: -20 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                transition={{ delay: 0.1 }}
              >
                <Card className="h-full hover:shadow-xl transition-shadow">
                  <CardHeader>
                    <div className="w-14 h-14 rounded-xl bg-primary/10 flex items-center justify-center mb-4">
                      <Globe className="h-7 w-7 text-primary" />
                    </div>
                    <CardTitle>{marketAnalysis.sectorStatus.title}</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <ul className="space-y-3">
                      {marketAnalysis.sectorStatus.points.map((point, index) => (
                        <li key={index} className="flex items-start gap-3">
                          <CheckCircle2 className="h-5 w-5 text-primary flex-shrink-0 mt-0.5" />
                          <span className="text-muted-foreground">{point}</span>
                        </li>
                      ))}
                    </ul>
                  </CardContent>
                </Card>
              </motion.div>
            </div>
          </div>
        </section>

        {/* Challenges & Opportunities */}
        <section className="py-16 bg-muted/30">
          <div className="container mx-auto px-4">
            <div className="grid md:grid-cols-2 gap-8 max-w-5xl mx-auto">
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
              >
                <Card className="h-full border-destructive/20 bg-destructive/5 hover:shadow-xl transition-shadow">
                  <CardHeader>
                    <div className="w-14 h-14 rounded-xl bg-destructive/10 flex items-center justify-center mb-4">
                      <AlertTriangle className="h-7 w-7 text-destructive" />
                    </div>
                    <CardTitle>الإشكالات الرئيسية</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <ul className="space-y-3">
                      {marketAnalysis.challenges.map((challenge, index) => (
                        <li key={index} className="flex items-start gap-3">
                          <div className="w-6 h-6 rounded-full bg-destructive/10 flex items-center justify-center flex-shrink-0 mt-0.5">
                            <span className="text-xs font-bold text-destructive">{index + 1}</span>
                          </div>
                          <span className="text-muted-foreground">{challenge}</span>
                        </li>
                      ))}
                    </ul>
                  </CardContent>
                </Card>
              </motion.div>

              <motion.div
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: 0.1 }}
              >
                <Card className="h-full border-primary/20 bg-primary/5 hover:shadow-xl transition-shadow">
                  <CardHeader>
                    <div className="w-14 h-14 rounded-xl bg-primary/10 flex items-center justify-center mb-4">
                      <TrendingUp className="h-7 w-7 text-primary" />
                    </div>
                    <CardTitle>الفرص السوقية</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <ul className="space-y-3">
                      {marketAnalysis.opportunities.map((opportunity, index) => (
                        <li key={index} className="flex items-start gap-3">
                          <CheckCircle2 className="h-5 w-5 text-primary flex-shrink-0 mt-0.5" />
                          <span className="text-muted-foreground">{opportunity}</span>
                        </li>
                      ))}
                    </ul>
                  </CardContent>
                </Card>
              </motion.div>
            </div>
          </div>
        </section>

        {/* Target Customers */}
        <section className="py-16 md:py-24 bg-background">
          <div className="container mx-auto px-4">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              className="text-center mb-12"
            >
              <h2 className="text-2xl md:text-3xl font-bold text-foreground mb-4">
                المستفيدون / الزبائن
              </h2>
            </motion.div>

            <div className="flex flex-wrap justify-center gap-4 max-w-4xl mx-auto">
              {marketAnalysis.targetCustomers.map((customer, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, scale: 0.9 }}
                  whileInView={{ opacity: 1, scale: 1 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.5, delay: index * 0.1 }}
                >
                  <div className="flex items-center gap-3 bg-muted/50 rounded-full px-6 py-3 hover:bg-primary/10 transition-colors">
                    <Users className="h-5 w-5 text-primary" />
                    <span className="font-medium text-foreground">{customer}</span>
                  </div>
                </motion.div>
              ))}
            </div>
          </div>
        </section>

        {/* Value Proposition */}
        <section className="py-16 bg-muted/30">
          <div className="container mx-auto px-4">
            <div className="max-w-4xl mx-auto">
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
              >
                <Card className="hover:shadow-xl transition-shadow">
                  <CardHeader className="text-center">
                    <div className="w-20 h-20 rounded-full bg-primary/10 flex items-center justify-center mx-auto mb-6">
                      <Target className="h-10 w-10 text-primary" />
                    </div>
                    <CardTitle className="text-2xl">{marketAnalysis.valueProposition.title}</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="grid md:grid-cols-2 gap-4">
                      {marketAnalysis.valueProposition.points.map((point, index) => (
                        <div key={index} className="flex items-center gap-3 p-4 rounded-lg bg-muted/50">
                          <CheckCircle2 className="h-5 w-5 text-primary flex-shrink-0" />
                          <span className="text-foreground font-medium">{point}</span>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            </div>
          </div>
        </section>

        {/* Competitive Analysis */}
        <section className="py-16 md:py-24 bg-background">
          <div className="container mx-auto px-4">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              className="text-center mb-12"
            >
              <h2 className="text-2xl md:text-3xl font-bold text-foreground mb-4">
                قياس شدة المنافسة
              </h2>
              <p className="text-lg text-muted-foreground">
                شدة المنافسة: <span className="font-bold text-primary">{marketAnalysis.competitiveAnalysis.intensity}</span>
              </p>
            </motion.div>

            <div className="grid md:grid-cols-3 gap-6 max-w-5xl mx-auto">
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
              >
                <Card className="h-full border-primary/20 bg-primary/5">
                  <CardHeader>
                    <CardTitle className="text-lg">عوامل التخفيف</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <ul className="space-y-2">
                      {marketAnalysis.competitiveAnalysis.advantages.map((adv, i) => (
                        <li key={i} className="flex items-start gap-2">
                          <CheckCircle2 className="h-4 w-4 text-primary flex-shrink-0 mt-0.5" />
                          <span className="text-sm text-muted-foreground">{adv}</span>
                        </li>
                      ))}
                    </ul>
                  </CardContent>
                </Card>
              </motion.div>

              <motion.div
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: 0.1 }}
              >
                <Card className="h-full border-destructive/20 bg-destructive/5">
                  <CardHeader>
                    <CardTitle className="text-lg">المخاطر المحتملة</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <ul className="space-y-2">
                      {marketAnalysis.competitiveAnalysis.risks.map((risk, i) => (
                        <li key={i} className="flex items-start gap-2">
                          <AlertTriangle className="h-4 w-4 text-destructive flex-shrink-0 mt-0.5" />
                          <span className="text-sm text-muted-foreground">{risk}</span>
                        </li>
                      ))}
                    </ul>
                  </CardContent>
                </Card>
              </motion.div>

              <motion.div
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: 0.2 }}
              >
                <Card className="h-full border-accent/20 bg-accent/5">
                  <CardHeader>
                    <CardTitle className="text-lg">آليات المواجهة</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <ul className="space-y-2">
                      {marketAnalysis.competitiveAnalysis.mitigationStrategies.map((strat, i) => (
                        <li key={i} className="flex items-start gap-2">
                          <Shield className="h-4 w-4 text-accent flex-shrink-0 mt-0.5" />
                          <span className="text-sm text-muted-foreground">{strat}</span>
                        </li>
                      ))}
                    </ul>
                  </CardContent>
                </Card>
              </motion.div>
            </div>
          </div>
        </section>

        {/* Navigation */}
        <section className="py-12 bg-muted/30 border-t border-border">
          <div className="container mx-auto px-4">
            <div className="flex flex-col sm:flex-row items-center justify-between gap-4">
              <Button asChild variant="outline" className="group">
                <Link href="/">
                  <Home className="ml-2 h-4 w-4" />
                  العودة للرئيسية
                </Link>
              </Button>
              <div className="flex items-center gap-4">
                <Button asChild variant="outline" className="group">
                  <Link href="/innovation">
                    <ChevronLeft className="ml-2 h-4 w-4 rotate-180" />
                    الجوانب الابتكارية
                  </Link>
                </Button>
                <Button asChild className="group">
                  <Link href="/marketing">
                    استراتيجية التسويق
                    <ChevronLeft className="mr-2 h-4 w-4" />
                  </Link>
                </Button>
              </div>
            </div>
          </div>
        </section>
      </main>

      <Footer />
    </div>
  )
}
