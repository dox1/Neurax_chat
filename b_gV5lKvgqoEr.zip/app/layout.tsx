import type { Metadata, Viewport } from 'next'
import { IBM_Plex_Sans_Arabic, Geist_Mono } from 'next/font/google'
import { Analytics } from '@vercel/analytics/next'
import './globals.css'

const ibmPlexArabic = IBM_Plex_Sans_Arabic({
  subsets: ['arabic', 'latin'],
  weight: ['300', '400', '500', '600', '700'],
  variable: '--font-sans',
  display: 'swap',
})

const geistMono = Geist_Mono({
  subsets: ['latin'],
  variable: '--font-mono',
  display: 'swap',
})

export const metadata: Metadata = {
  title: 'نوران | المنصة الرقمية للوقاية من جرائم الفساد في الصفقات العمومية',
  description: 'منصة رقمية ذكية ومؤسساتية مخصصة للوقاية من جرائم الفساد في الصفقات العمومية، وتعزيز الشفافية، وترسيخ الحكامة الجيدة، ودعم الرقابة الاستباقية',
  keywords: ['نوران', 'الفساد', 'الصفقات العمومية', 'الشفافية', 'الحكامة', 'الرقابة', 'مكافحة الفساد', 'المساءلة'],
  authors: [{ name: 'Nouran Platform' }],
  creator: 'Nouran',
  publisher: 'Nouran',
  robots: 'index, follow',
  openGraph: {
    type: 'website',
    locale: 'ar_AR',
    url: 'https://nouran.ma',
    siteName: 'نوران - Nouran',
    title: 'نوران | المنصة الرقمية للوقاية من جرائم الفساد في الصفقات العمومية',
    description: 'منصة رقمية ذكية ومؤسساتية مخصصة للوقاية من جرائم الفساد في الصفقات العمومية',
  },
  twitter: {
    card: 'summary_large_image',
    title: 'نوران | Nouran',
    description: 'المنصة الرقمية للوقاية من جرائم الفساد في الصفقات العمومية',
  },
  icons: {
    icon: [
      { url: '/favicon.svg', type: 'image/svg+xml' },
    ],
    apple: '/apple-icon.png',
  },
}

export const viewport: Viewport = {
  width: 'device-width',
  initialScale: 1,
  maximumScale: 5,
  themeColor: [
    { media: '(prefers-color-scheme: light)', color: '#1e3a5f' },
    { media: '(prefers-color-scheme: dark)', color: '#0f172a' },
  ],
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html lang="ar" dir="rtl" className="bg-background scroll-smooth">
      <body className={`${ibmPlexArabic.variable} ${geistMono.variable} font-sans antialiased min-h-screen`}>
        {children}
        {process.env.NODE_ENV === 'production' && <Analytics />}
      </body>
    </html>
  )
}
