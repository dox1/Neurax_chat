"use client"

import Link from "next/link"
import { useParams } from "next/navigation"
import { motion } from "framer-motion"
import {
  ArrowLeft,
  Home,
  BookOpen,
  Calendar,
  Tag,
} from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Header } from "@/components/layout/header"
import { Footer } from "@/components/layout/footer"
import { PageHero } from "@/components/ui/page-hero"
import { categories, articles } from "@/lib/data"

export default function CategoryDetailPage() {
  const params = useParams()
  const categoryId = params.id as string
  
  const category = categories.find(c => c.id === categoryId)
  const categoryArticles = articles.filter(a => 
    a.category.toLowerCase().includes(category?.name.toLowerCase() || '') ||
    category?.name.toLowerCase().includes(a.category.toLowerCase())
  )

  if (!category) {
    return (
      <div className="min-h-screen flex flex-col">
        <Header />
        <main className="flex-1 flex items-center justify-center">
          <div className="text-center">
            <h1 className="text-2xl font-bold mb-4">التصنيف غير موجود</h1>
            <Button asChild>
              <Link href="/categories">العودة للتصنيفات</Link>
            </Button>
          </div>
        </main>
        <Footer />
      </div>
    )
  }

  return (
    <div className="min-h-screen flex flex-col">
      <Header />

      <main className="flex-1">
        <PageHero
          title={category.name}
          subtitle="التصنيف"
          description={category.description}
          breadcrumbs={[
            { label: "الرئيسية", href: "/" },
            { label: "التصنيفات", href: "/categories" },
            { label: category.name, href: `/categories/${category.id}` },
          ]}
        />

        <section className="py-16 md:py-24 bg-background">
          <div className="container mx-auto px-4">
            {categoryArticles.length > 0 ? (
              <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
                {categoryArticles.map((article, index) => (
                  <motion.div
                    key={article.id}
                    initial={{ opacity: 0, y: 20 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    viewport={{ once: true }}
                    transition={{ duration: 0.5, delay: index * 0.1 }}
                  >
                    <Link href={`/articles/${article.id}`} className="block group">
                      <Card className="h-full overflow-hidden hover:shadow-xl transition-all duration-300">
                        <div className="aspect-video bg-gradient-to-br from-primary/20 to-accent/20 relative">
                          <div className="absolute inset-0 flex items-center justify-center">
                            <BookOpen className="h-16 w-16 text-primary/30" />
                          </div>
                          <div className="absolute bottom-4 right-4">
                            <span className="bg-primary text-primary-foreground text-xs font-medium px-3 py-1 rounded-full">
                              {article.category}
                            </span>
                          </div>
                        </div>
                        <CardContent className="p-6">
                          <div className="flex items-center gap-2 text-sm text-muted-foreground mb-4">
                            <Calendar className="h-4 w-4" />
                            {new Date(article.date).toLocaleDateString("ar-MA", {
                              year: "numeric",
                              month: "long",
                              day: "numeric",
                            })}
                          </div>
                          <h3 className="font-bold text-lg text-foreground mb-3 group-hover:text-primary transition-colors line-clamp-2">
                            {article.title}
                          </h3>
                          <p className="text-muted-foreground text-sm line-clamp-3">
                            {article.excerpt}
                          </p>
                        </CardContent>
                      </Card>
                    </Link>
                  </motion.div>
                ))}
              </div>
            ) : (
              <div className="text-center py-16">
                <div className="w-20 h-20 rounded-full bg-muted flex items-center justify-center mx-auto mb-6">
                  <Tag className="h-10 w-10 text-muted-foreground" />
                </div>
                <h2 className="text-2xl font-bold text-foreground mb-4">
                  لا توجد مقالات في هذا التصنيف
                </h2>
                <p className="text-muted-foreground mb-8">
                  سيتم إضافة مقالات جديدة قريبًا
                </p>
                <Button asChild>
                  <Link href="/articles">
                    تصفح جميع المقالات
                    <ArrowLeft className="mr-2 h-4 w-4" />
                  </Link>
                </Button>
              </div>
            )}
          </div>
        </section>

        {/* Navigation */}
        <section className="py-12 bg-muted/30 border-t border-border">
          <div className="container mx-auto px-4">
            <div className="flex flex-col sm:flex-row items-center justify-between gap-4">
              <Button asChild variant="outline" className="group">
                <Link href="/categories">
                  <ArrowLeft className="ml-2 h-4 w-4 rotate-180" />
                  جميع التصنيفات
                </Link>
              </Button>
              <Button asChild className="group">
                <Link href="/articles">
                  جميع المقالات
                  <ArrowLeft className="mr-2 h-4 w-4 group-hover:-translate-x-1 transition-transform" />
                </Link>
              </Button>
            </div>
          </div>
        </section>
      </main>

      <Footer />
    </div>
  )
}
