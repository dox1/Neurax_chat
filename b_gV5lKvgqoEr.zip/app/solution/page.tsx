"use client"

import Link from "next/link"
import { motion } from "framer-motion"
import {
  ArrowLeft,
  ArrowRight,
  Database,
  Eye,
  Scale,
  ShieldCheck,
  Route,
  FileSearch,
  PieChart,
  CheckCircle2,
} from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Header } from "@/components/layout/header"
import { Footer } from "@/components/layout/footer"
import { PageHero } from "@/components/ui/page-hero"
import { solution } from "@/lib/data"

const iconMap: Record<string, React.ComponentType<{ className?: string }>> = {
  Database,
  Eye,
  Scale,
  ShieldCheck,
  Route,
  FileSearch,
  PieChart,
}

export default function SolutionPage() {
  return (
    <div className="min-h-screen flex flex-col">
      <Header />

      <main className="flex-1">
        <PageHero
          title={solution.title}
          subtitle={solution.subtitle}
          description={solution.description}
          breadcrumbs={[{ label: "الحل المقترح" }]}
        />

        {/* Pillars Section */}
        <section className="py-16 md:py-24 bg-background">
          <div className="container mx-auto px-4">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
              className="text-center mb-16"
            >
              <h2 className="text-2xl md:text-3xl font-bold text-foreground mb-4">
                ركائز الحل
              </h2>
              <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
                يقوم الحل المقترح على مجموعة من الركائز الأساسية المتكاملة
              </p>
            </motion.div>

            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
              {solution.pillars.map((pillar, index) => {
                const IconComponent = iconMap[pillar.icon] || ShieldCheck
                return (
                  <motion.div
                    key={index}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.5, delay: index * 0.1 }}
                  >
                    <Card className="h-full border-primary/20 bg-primary/5 hover:shadow-lg hover:border-primary/40 transition-all group">
                      <CardHeader>
                        <div className="w-14 h-14 rounded-xl bg-primary/10 flex items-center justify-center mb-4 group-hover:bg-primary group-hover:text-primary-foreground transition-colors">
                          <IconComponent className="h-7 w-7 text-primary group-hover:text-primary-foreground transition-colors" />
                        </div>
                        <CardTitle className="text-lg">{pillar.title}</CardTitle>
                      </CardHeader>
                      <CardContent>
                        <CardDescription className="text-base">
                          {pillar.description}
                        </CardDescription>
                      </CardContent>
                    </Card>
                  </motion.div>
                )
              })}
            </div>
          </div>
        </section>

        {/* How It Works Overview */}
        <section className="py-16 md:py-24 bg-muted/30">
          <div className="container mx-auto px-4">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              className="max-w-4xl mx-auto"
            >
              <div className="text-center mb-12">
                <h2 className="text-2xl md:text-3xl font-bold text-foreground mb-4">
                  كيف يعمل الحل؟
                </h2>
                <p className="text-lg text-muted-foreground">
                  نظرة شاملة على آليات عمل منصة نوران
                </p>
              </div>

              <div className="space-y-6">
                {[
                  {
                    step: 1,
                    title: "جمع وتنظيم البيانات",
                    description: "تجميع القوانين والتنظيمات والآراء القانونية في قاعدة بيانات موحدة",
                  },
                  {
                    step: 2,
                    title: "التحليل الذكي",
                    description: "استخدام خوارزميات الذكاء الاصطناعي لتحليل البيانات واكتشاف المؤشرات",
                  },
                  {
                    step: 3,
                    title: "الإنذار المبكر",
                    description: "رصد الأنماط غير الطبيعية وإطلاق تنبيهات استباقية",
                  },
                  {
                    step: 4,
                    title: "دعم القرار",
                    description: "توفير لوحات قيادة وتقارير تحليلية للجهات المعنية",
                  },
                ].map((item, index) => (
                  <motion.div
                    key={index}
                    initial={{ opacity: 0, x: 20 }}
                    whileInView={{ opacity: 1, x: 0 }}
                    viewport={{ once: true }}
                    transition={{ duration: 0.5, delay: index * 0.1 }}
                  >
                    <Card className="border-border/50 hover:border-primary/30 transition-colors">
                      <CardContent className="p-6 flex items-start gap-6">
                        <div className="w-12 h-12 rounded-full bg-primary text-primary-foreground flex items-center justify-center flex-shrink-0 font-bold text-lg">
                          {item.step}
                        </div>
                        <div>
                          <h3 className="text-lg font-semibold text-foreground mb-2">
                            {item.title}
                          </h3>
                          <p className="text-muted-foreground">{item.description}</p>
                        </div>
                      </CardContent>
                    </Card>
                  </motion.div>
                ))}
              </div>

              <motion.div
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                className="text-center mt-10"
              >
                <Button asChild size="lg" className="group">
                  <Link href="/how-it-works">
                    التفاصيل الكاملة
                    <ArrowLeft className="mr-2 h-4 w-4 group-hover:-translate-x-1 transition-transform" />
                  </Link>
                </Button>
              </motion.div>
            </motion.div>
          </div>
        </section>

        {/* Benefits */}
        <section className="py-16 md:py-24 bg-primary text-primary-foreground">
          <div className="container mx-auto px-4">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              className="text-center mb-12"
            >
              <h2 className="text-2xl md:text-3xl font-bold mb-4">
                مزايا الحل
              </h2>
              <p className="text-lg text-primary-foreground/80">
                ما يجعل منصة نوران الخيار الأمثل
              </p>
            </motion.div>

            <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
              {[
                { title: "الوقاية الاستباقية", description: "الكشف المبكر عن المخاطر قبل وقوعها" },
                { title: "الشفافية الكاملة", description: "إتاحة المعلومات للجميع بشكل عادل" },
                { title: "الحماية والسرية", description: "ضمان حماية المبلغين والبيانات" },
                { title: "دعم القرار", description: "تقارير وتحليلات ذكية ومتقدمة" },
              ].map((benefit, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.5, delay: index * 0.1 }}
                  className="bg-white/10 backdrop-blur-sm rounded-xl p-6 hover:bg-white/15 transition-colors"
                >
                  <CheckCircle2 className="h-8 w-8 text-accent mb-4" />
                  <h3 className="text-lg font-semibold mb-2">{benefit.title}</h3>
                  <p className="text-primary-foreground/80 text-sm">{benefit.description}</p>
                </motion.div>
              ))}
            </div>
          </div>
        </section>

        {/* Navigation */}
        <section className="py-8 bg-background border-t border-border">
          <div className="container mx-auto px-4">
            <div className="flex items-center justify-between">
              <Button asChild variant="ghost" className="group">
                <Link href="/problem">
                  <ArrowRight className="ml-2 h-4 w-4 group-hover:translate-x-1 transition-transform" />
                  فكرة المشروع
                </Link>
              </Button>
              <Button asChild className="group">
                <Link href="/how-it-works">
                  كيف تعالج نوران المشكلة
                  <ArrowLeft className="mr-2 h-4 w-4 group-hover:-translate-x-1 transition-transform" />
                </Link>
              </Button>
            </div>
          </div>
        </section>
      </main>

      <Footer />
    </div>
  )
}
