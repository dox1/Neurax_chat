"use client"

import Link from "next/link"
import { motion } from "framer-motion"
import {
  Home,
  Mail,
  Phone,
  MapPin,
  Send,
  Facebook,
  Twitter,
  Linkedin,
  Shield,
} from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Header } from "@/components/layout/header"
import { Footer } from "@/components/layout/footer"
import { PageHero } from "@/components/ui/page-hero"
import { contact } from "@/lib/data"

export default function ContactPage() {
  return (
    <div className="min-h-screen flex flex-col">
      <Header />

      <main className="flex-1">
        <PageHero
          title={contact.title}
          subtitle={contact.subtitle}
          description="نحن هنا للإجابة على استفساراتكم ومساعدتكم"
          breadcrumbs={[
            { label: "الرئيسية", href: "/" },
            { label: "اتصل بنا", href: "/contact" },
          ]}
        />

        <section className="py-16 md:py-24 bg-background">
          <div className="container mx-auto px-4">
            <div className="grid lg:grid-cols-2 gap-12 max-w-6xl mx-auto">
              {/* Contact Form */}
              <motion.div
                initial={{ opacity: 0, x: 20 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
              >
                <Card className="h-full">
                  <CardHeader>
                    <CardTitle className="text-2xl">أرسل رسالتك</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <form className="space-y-6">
                      <div className="grid md:grid-cols-2 gap-4">
                        <div>
                          <label className="block text-sm font-medium text-foreground mb-2">
                            الاسم الكامل *
                          </label>
                          <Input placeholder="أدخل اسمك الكامل" />
                        </div>
                        <div>
                          <label className="block text-sm font-medium text-foreground mb-2">
                            البريد الإلكتروني *
                          </label>
                          <Input type="email" placeholder="example@email.com" />
                        </div>
                      </div>
                      <div className="grid md:grid-cols-2 gap-4">
                        <div>
                          <label className="block text-sm font-medium text-foreground mb-2">
                            رقم الهاتف
                          </label>
                          <Input type="tel" placeholder="+212 XXXXXXXXX" />
                        </div>
                        <div>
                          <label className="block text-sm font-medium text-foreground mb-2">
                            الموضوع *
                          </label>
                          <Input placeholder="موضوع الرسالة" />
                        </div>
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-foreground mb-2">
                          الرسالة *
                        </label>
                        <textarea
                          className="w-full min-h-[150px] px-4 py-3 rounded-lg border border-input bg-background text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-ring resize-none"
                          placeholder="اكتب رسالتك هنا..."
                        />
                      </div>
                      <Button type="submit" size="lg" className="w-full">
                        <Send className="ml-2 h-5 w-5" />
                        إرسال الرسالة
                      </Button>
                    </form>
                  </CardContent>
                </Card>
              </motion.div>

              {/* Contact Info */}
              <motion.div
                initial={{ opacity: 0, x: -20 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                transition={{ delay: 0.1 }}
                className="space-y-6"
              >
                {/* Contact Details */}
                <Card>
                  <CardHeader>
                    <CardTitle className="text-2xl">معلومات التواصل</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-6">
                    <div className="flex items-start gap-4">
                      <div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center flex-shrink-0">
                        <Mail className="h-6 w-6 text-primary" />
                      </div>
                      <div>
                        <h3 className="font-semibold text-foreground mb-1">البريد الإلكتروني</h3>
                        <a href={`mailto:${contact.email}`} className="text-muted-foreground hover:text-primary transition-colors">
                          {contact.email}
                        </a>
                      </div>
                    </div>
                    <div className="flex items-start gap-4">
                      <div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center flex-shrink-0">
                        <Phone className="h-6 w-6 text-primary" />
                      </div>
                      <div>
                        <h3 className="font-semibold text-foreground mb-1">رقم الهاتف</h3>
                        <a href={`tel:${contact.phone}`} className="text-muted-foreground hover:text-primary transition-colors">
                          {contact.phone}
                        </a>
                      </div>
                    </div>
                    <div className="flex items-start gap-4">
                      <div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center flex-shrink-0">
                        <MapPin className="h-6 w-6 text-primary" />
                      </div>
                      <div>
                        <h3 className="font-semibold text-foreground mb-1">العنوان</h3>
                        <p className="text-muted-foreground mb-2">{contact.address}</p>
                        <a 
                          href={contact.mapUrl} 
                          target="_blank" 
                          rel="noopener noreferrer"
                          className="text-primary hover:underline text-sm"
                        >
                          عرض الموقع على الخريطة
                        </a>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                {/* Social Media */}
                <Card>
                  <CardHeader>
                    <CardTitle>تابعونا</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="flex items-center gap-4">
                      <a
                        href={contact.socialMedia.facebook}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center hover:bg-primary hover:text-primary-foreground transition-colors"
                      >
                        <Facebook className="h-5 w-5" />
                      </a>
                      <a
                        href={contact.socialMedia.twitter}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center hover:bg-primary hover:text-primary-foreground transition-colors"
                      >
                        <Twitter className="h-5 w-5" />
                      </a>
                      <a
                        href={contact.socialMedia.linkedin}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center hover:bg-primary hover:text-primary-foreground transition-colors"
                      >
                        <Linkedin className="h-5 w-5" />
                      </a>
                    </div>
                  </CardContent>
                </Card>

                {/* Secure Reporting */}
                <Card className="border-accent/50 bg-accent/5">
                  <CardContent className="p-6">
                    <div className="flex items-start gap-4">
                      <div className="w-14 h-14 rounded-xl bg-accent/20 flex items-center justify-center flex-shrink-0">
                        <Shield className="h-7 w-7 text-accent" />
                      </div>
                      <div>
                        <h3 className="font-bold text-foreground mb-2">التبليغ السري والآمن</h3>
                        <p className="text-sm text-muted-foreground mb-4">
                          للتبليغ عن مؤشرات الفساد بشكل آمن وسري مع ضمان حماية هويتك
                        </p>
                        <Button asChild variant="outline" className="border-accent text-accent hover:bg-accent hover:text-accent-foreground">
                          <Link href="/services/reporting">
                            التبليغ الآن
                          </Link>
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            </div>
          </div>
        </section>

        {/* Navigation */}
        <section className="py-12 bg-muted/30 border-t border-border">
          <div className="container mx-auto px-4">
            <div className="flex flex-col sm:flex-row items-center justify-between gap-4">
              <Button asChild variant="outline" className="group">
                <Link href="/">
                  <Home className="ml-2 h-4 w-4" />
                  العودة للرئيسية
                </Link>
              </Button>
              <Button asChild className="group">
                <Link href="/faq">
                  الأسئلة الشائعة
                </Link>
              </Button>
            </div>
          </div>
        </section>
      </main>

      <Footer />
    </div>
  )
}
