"use client"

import Link from "next/link"
import { motion } from "framer-motion"
import {
  ChevronLeft,
  User,
  Briefcase,
  Award,
  Clock,
  CheckCircle2,
  Home,
  Users,
} from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Header } from "@/components/layout/header"
import { Footer } from "@/components/layout/footer"
import { PageHero } from "@/components/ui/page-hero"
import { team } from "@/lib/data"

export default function TeamPage() {
  return (
    <div className="min-h-screen flex flex-col">
      <Header />

      <main className="flex-1">
        <PageHero
          title={team.title}
          subtitle={team.subtitle}
          description={team.description}
          breadcrumbs={[
            { label: "الرئيسية", href: "/" },
            { label: "فريق العمل", href: "/team" },
          ]}
        />

        <section className="py-16 md:py-24 bg-background">
          <div className="container mx-auto px-4">
            <div className="grid md:grid-cols-2 gap-8 max-w-5xl mx-auto">
              {team.members.map((member, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.5, delay: index * 0.2 }}
                >
                  <Card className="h-full hover:shadow-xl transition-all duration-300 overflow-hidden group">
                    <div className="h-2 bg-gradient-to-r from-primary via-accent to-primary" />
                    <CardContent className="p-8">
                      {/* Avatar */}
                      <div className="flex flex-col items-center text-center mb-8">
                        <div className="w-32 h-32 rounded-full bg-gradient-to-br from-primary to-primary/80 flex items-center justify-center mb-6 group-hover:scale-105 transition-transform overflow-hidden ring-4 ring-primary/20">
                          {member.image ? (
                            <img
                              src={member.image}
                              alt={member.name}
                              className="w-full h-full object-cover"
                            />
                          ) : (
                            <User className="h-16 w-16 text-primary-foreground" />
                          )}
                        </div>
                        <h3 className="text-2xl font-bold text-foreground mb-2">
                          {member.name}
                        </h3>
                        <p className="text-accent font-semibold text-lg">
                          {member.role}
                        </p>
                      </div>

                      {/* Details */}
                      <div className="space-y-4 mb-8">
                        <div className="flex items-start gap-4 p-4 rounded-lg bg-muted/50">
                          <Award className="h-5 w-5 text-primary flex-shrink-0 mt-0.5" />
                          <div>
                            <p className="text-sm text-muted-foreground mb-1">المؤهل</p>
                            <p className="font-medium text-foreground">{member.qualification}</p>
                          </div>
                        </div>
                        <div className="flex items-start gap-4 p-4 rounded-lg bg-muted/50">
                          <Clock className="h-5 w-5 text-primary flex-shrink-0 mt-0.5" />
                          <div>
                            <p className="text-sm text-muted-foreground mb-1">الخبرة</p>
                            <p className="font-medium text-foreground">{member.experience}</p>
                          </div>
                        </div>
                      </div>

                      {/* Responsibilities */}
                      <div>
                        <h4 className="font-semibold text-foreground mb-4 flex items-center gap-2">
                          <Briefcase className="h-5 w-5 text-primary" />
                          المسؤوليات
                        </h4>
                        <ul className="space-y-3">
                          {member.responsibilities.map((resp, i) => (
                            <li key={i} className="flex items-start gap-3">
                              <CheckCircle2 className="h-5 w-5 text-primary flex-shrink-0 mt-0.5" />
                              <span className="text-muted-foreground">{resp}</span>
                            </li>
                          ))}
                        </ul>
                      </div>
                    </CardContent>
                  </Card>
                </motion.div>
              ))}
            </div>
          </div>
        </section>

        {/* Team Synergy Section */}
        <section className="py-16 bg-primary text-primary-foreground">
          <div className="container mx-auto px-4">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              className="max-w-4xl mx-auto text-center"
            >
              <div className="w-20 h-20 rounded-full bg-white/10 flex items-center justify-center mx-auto mb-8">
                <Users className="h-10 w-10 text-accent" />
              </div>
              <h2 className="text-2xl md:text-3xl font-bold mb-6">
                تكامل الفريق
              </h2>
              <p className="text-lg text-primary-foreground/90 leading-relaxed">
                {team.teamSynergy}
              </p>
            </motion.div>
          </div>
        </section>

        {/* Navigation */}
        <section className="py-12 bg-background border-t border-border">
          <div className="container mx-auto px-4">
            <div className="flex flex-col sm:flex-row items-center justify-between gap-4">
              <Button asChild variant="outline" className="group">
                <Link href="/">
                  <Home className="ml-2 h-4 w-4" />
                  العودة للرئيسية
                </Link>
              </Button>
              <div className="flex items-center gap-4">
                <Button asChild variant="outline" className="group">
                  <Link href="/values">
                    <ChevronLeft className="ml-2 h-4 w-4 rotate-180" />
                    القيم
                  </Link>
                </Button>
                <Button asChild className="group">
                  <Link href="/objectives">
                    الأهداف
                    <ChevronLeft className="mr-2 h-4 w-4" />
                  </Link>
                </Button>
              </div>
            </div>
          </div>
        </section>
      </main>

      <Footer />
    </div>
  )
}
