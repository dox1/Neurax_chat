"use client"

import Link from "next/link"
import Image from "next/image"
import {
  Mail,
  Phone,
  MapPin,
  Facebook,
  Twitter,
  Linkedin,
  Shield,
  ArrowUp,
  ChevronLeft,
} from "lucide-react"
import { Button } from "@/components/ui/button"

const footerLinks = {
  about: [
    { name: "مقدمة", href: "/introduction" },
    { name: "فكرة المشروع", href: "/problem" },
    { name: "الحل المقترح", href: "/solution" },
    { name: "فريق العمل", href: "/team" },
    { name: "الأهداف", href: "/objectives" },
  ],
  services: [
    { name: "الخدمات", href: "/services" },
    { name: "المقالات", href: "/articles" },
    { name: "الوثائق", href: "/documents" },
    { name: "الأسئلة الشائعة", href: "/faq" },
    { name: "اتصل بنا", href: "/contact" },
  ],
  resources: [
    { name: "القيم", href: "/values" },
    { name: "الجوانب الابتكارية", href: "/innovation" },
    { name: "التحليل الاستراتيجي", href: "/market-analysis" },
    { name: "الخطة المالية", href: "/financial" },
    { name: "شرائح العملاء", href: "/customers" },
  ],
}

export function Footer() {
  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: "smooth" })
  }

  return (
    <footer className="bg-primary text-primary-foreground">
      {/* Main Footer */}
      <div className="container mx-auto px-4 py-16">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-12">
          {/* Brand Column */}
          <div className="lg:col-span-2 space-y-6">
            <Link href="/" className="flex items-center gap-3 group">
              <div className="relative w-16 h-16 rounded-lg overflow-hidden group-hover:opacity-90 transition-opacity">
                <Image
                  src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/1777042234066-DUchF5f3SaoIl45GB3sM8ouvdvhPY0.jpg"
                  alt="نوران"
                  fill
                  className="object-cover"
                />
              </div>
              <div className="flex flex-col">
                <span className="text-2xl font-bold text-white">نوران</span>
                <span className="text-sm text-white/80">للوقاية من الفساد</span>
              </div>
            </Link>

            <p className="text-white/80 leading-relaxed max-w-md">
              المنصة الرقمية للوقاية من جرائم الفساد في الصفقات العمومية. نسعى
              لتعزيز الشفافية والحكامة الجيدة ودعم الرقابة الاستباقية وحماية
              المال العام.
            </p>

            <div className="flex items-center gap-3">
              <a
                href="#"
                className="w-10 h-10 bg-white/10 rounded-full flex items-center justify-center hover:bg-accent hover:text-accent-foreground transition-colors"
                aria-label="Facebook"
              >
                <Facebook className="h-5 w-5" />
              </a>
              <a
                href="#"
                className="w-10 h-10 bg-white/10 rounded-full flex items-center justify-center hover:bg-accent hover:text-accent-foreground transition-colors"
                aria-label="Twitter"
              >
                <Twitter className="h-5 w-5" />
              </a>
              <a
                href="#"
                className="w-10 h-10 bg-white/10 rounded-full flex items-center justify-center hover:bg-accent hover:text-accent-foreground transition-colors"
                aria-label="LinkedIn"
              >
                <Linkedin className="h-5 w-5" />
              </a>
            </div>
          </div>

          {/* Links Column 1 */}
          <div>
            <h3 className="text-lg font-semibold mb-6 text-accent">حول المنصة</h3>
            <ul className="space-y-3">
              {footerLinks.about.map((link) => (
                <li key={link.href}>
                  <Link
                    href={link.href}
                    className="flex items-center gap-2 text-white/80 hover:text-accent transition-colors group"
                  >
                    <ChevronLeft className="h-4 w-4 opacity-0 group-hover:opacity-100 transition-opacity" />
                    <span>{link.name}</span>
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Links Column 2 */}
          <div>
            <h3 className="text-lg font-semibold mb-6 text-accent">الخدمات والموارد</h3>
            <ul className="space-y-3">
              {footerLinks.services.map((link) => (
                <li key={link.href}>
                  <Link
                    href={link.href}
                    className="flex items-center gap-2 text-white/80 hover:text-accent transition-colors group"
                  >
                    <ChevronLeft className="h-4 w-4 opacity-0 group-hover:opacity-100 transition-opacity" />
                    <span>{link.name}</span>
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Contact Column */}
          <div>
            <h3 className="text-lg font-semibold mb-6 text-accent">تواصل معنا</h3>
            <ul className="space-y-4">
              <li>
                <a
                  href="mailto:moh_esp@yahoo.fr"
                  className="flex items-start gap-3 text-white/80 hover:text-accent transition-colors"
                >
                  <Mail className="h-5 w-5 mt-0.5 flex-shrink-0" />
                  <span>moh_esp@yahoo.fr</span>
                </a>
              </li>
              <li>
                <a
                  href="tel:+213661280110"
                  className="flex items-start gap-3 text-white/80 hover:text-accent transition-colors"
                >
                  <Phone className="h-5 w-5 mt-0.5 flex-shrink-0" />
                  <span dir="ltr">0661280110</span>
                </a>
              </li>
              <li>
                <a
                  href="https://maps.app.goo.gl/ZQaH9KmQKB4k8ayZA?g_st=aw"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-start gap-3 text-white/80 hover:text-accent transition-colors"
                >
                  <MapPin className="h-5 w-5 mt-0.5 flex-shrink-0" />
                  <span>عرض الموقع على الخريطة</span>
                </a>
              </li>
            </ul>

            <div className="mt-6">
              <Button
                asChild
                className="w-full bg-accent hover:bg-accent/90 text-accent-foreground"
              >
                <Link href="/contact">أرسل رسالة</Link>
              </Button>
            </div>
          </div>
        </div>
      </div>

      {/* Bottom Bar */}
      <div className="border-t border-white/10">
        <div className="container mx-auto px-4 py-6">
          <div className="flex flex-col md:flex-row items-center justify-between gap-4">
            <p className="text-white/70 text-sm text-center md:text-right">
              © {new Date().getFullYear()} نوران - Nouran. جميع الحقوق محفوظة.
            </p>
            <div className="flex items-center gap-6 text-sm text-white/70">
              <Link href="/privacy" className="hover:text-accent transition-colors">
                سياسة الخصوصية
              </Link>
              <Link href="/terms" className="hover:text-accent transition-colors">
                شروط الاستخدام
              </Link>
            </div>
            <Button
              variant="ghost"
              size="icon"
              onClick={scrollToTop}
              className="text-white/70 hover:text-accent hover:bg-white/10"
              aria-label="العودة للأعلى"
            >
              <ArrowUp className="h-5 w-5" />
            </Button>
          </div>
        </div>
      </div>
    </footer>
  )
}
