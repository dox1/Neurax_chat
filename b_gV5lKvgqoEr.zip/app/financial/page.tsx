"use client"

import Link from "next/link"
import { motion } from "framer-motion"
import {
  ChevronLeft,
  Home,
  Coins,
  TrendingUp,
  TrendingDown,
  DollarSign,
  PiggyBank,
  ArrowUpRight,
  ArrowDownRight,
} from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Header } from "@/components/layout/header"
import { Footer } from "@/components/layout/footer"
import { PageHero } from "@/components/ui/page-hero"
import { financialPlan } from "@/lib/data"

export default function FinancialPage() {
  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('ar-MA', {
      style: 'decimal',
      minimumFractionDigits: 0,
    }).format(amount) + ' درهم'
  }

  return (
    <div className="min-h-screen flex flex-col">
      <Header />

      <main className="flex-1">
        <PageHero
          title={financialPlan.title}
          subtitle={financialPlan.subtitle}
          description="التفاصيل المالية للمشروع من التكاليف والإيرادات إلى النتائج المتوقعة"
          breadcrumbs={[
            { label: "الرئيسية", href: "/" },
            { label: "الخطة المالية", href: "/financial" },
          ]}
        />

        {/* Initial Investment */}
        <section className="py-16 md:py-24 bg-background">
          <div className="container mx-auto px-4">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              className="text-center mb-12"
            >
              <div className="w-16 h-16 rounded-full bg-primary/10 flex items-center justify-center mx-auto mb-6">
                <Coins className="h-8 w-8 text-primary" />
              </div>
              <h2 className="text-2xl md:text-3xl font-bold text-foreground mb-4">
                {financialPlan.initialInvestment.title}
              </h2>
              <p className="text-3xl font-bold text-primary">
                {formatCurrency(financialPlan.initialInvestment.total)}
              </p>
            </motion.div>

            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4 max-w-5xl mx-auto">
              {financialPlan.initialInvestment.items.map((item, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.5, delay: index * 0.1 }}
                >
                  <Card className="h-full hover:shadow-lg transition-shadow">
                    <CardContent className="p-6">
                      <div className="flex items-center justify-between mb-4">
                        <span className="text-sm font-medium text-muted-foreground">{item.name}</span>
                        <span className="text-xs font-bold text-primary bg-primary/10 px-2 py-1 rounded-full">
                          {item.percentage}%
                        </span>
                      </div>
                      <p className="text-xl font-bold text-foreground">{formatCurrency(item.amount)}</p>
                      <div className="mt-3 h-2 bg-muted rounded-full overflow-hidden">
                        <motion.div
                          initial={{ width: 0 }}
                          whileInView={{ width: `${item.percentage}%` }}
                          viewport={{ once: true }}
                          transition={{ duration: 1, delay: index * 0.1 }}
                          className="h-full bg-gradient-to-l from-primary to-accent rounded-full"
                        />
                      </div>
                    </CardContent>
                  </Card>
                </motion.div>
              ))}
            </div>
          </div>
        </section>

        {/* Operating Costs */}
        <section className="py-16 bg-muted/30">
          <div className="container mx-auto px-4">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              className="text-center mb-12"
            >
              <div className="w-16 h-16 rounded-full bg-destructive/10 flex items-center justify-center mx-auto mb-6">
                <TrendingDown className="h-8 w-8 text-destructive" />
              </div>
              <h2 className="text-2xl md:text-3xl font-bold text-foreground mb-4">
                {financialPlan.operatingCosts.title}
              </h2>
              <p className="text-3xl font-bold text-destructive">
                {formatCurrency(financialPlan.operatingCosts.total)}
              </p>
            </motion.div>

            <div className="max-w-3xl mx-auto">
              <Card className="hover:shadow-xl transition-shadow">
                <CardContent className="p-6">
                  <div className="space-y-4">
                    {financialPlan.operatingCosts.items.map((item, index) => (
                      <motion.div
                        key={index}
                        initial={{ opacity: 0, x: 20 }}
                        whileInView={{ opacity: 1, x: 0 }}
                        viewport={{ once: true }}
                        transition={{ duration: 0.5, delay: index * 0.1 }}
                        className="flex items-center justify-between p-4 rounded-lg bg-muted/50"
                      >
                        <span className="font-medium text-foreground">{item.name}</span>
                        <span className="font-bold text-destructive">{formatCurrency(item.amount)}</span>
                      </motion.div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </section>

        {/* Revenue Streams */}
        <section className="py-16 md:py-24 bg-background">
          <div className="container mx-auto px-4">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              className="text-center mb-12"
            >
              <div className="w-16 h-16 rounded-full bg-primary/10 flex items-center justify-center mx-auto mb-6">
                <TrendingUp className="h-8 w-8 text-primary" />
              </div>
              <h2 className="text-2xl md:text-3xl font-bold text-foreground mb-4">
                {financialPlan.revenueStreams.title}
              </h2>
              <p className="text-3xl font-bold text-primary">
                {formatCurrency(financialPlan.revenueStreams.total)}
              </p>
            </motion.div>

            <div className="grid md:grid-cols-2 gap-6 max-w-4xl mx-auto">
              {financialPlan.revenueStreams.streams.map((stream, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.5, delay: index * 0.1 }}
                >
                  <Card className="h-full hover:shadow-xl hover:border-primary/30 transition-all">
                    <CardContent className="p-6">
                      <div className="flex items-start gap-4">
                        <div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center flex-shrink-0">
                          <DollarSign className="h-6 w-6 text-primary" />
                        </div>
                        <div className="flex-1">
                          <h3 className="font-bold text-foreground mb-2">{stream.name}</h3>
                          <p className="text-sm text-muted-foreground mb-4">{stream.description}</p>
                          <p className="text-lg font-bold text-primary">{formatCurrency(stream.expectedRevenue)}</p>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </motion.div>
              ))}
            </div>
          </div>
        </section>

        {/* Projected Results */}
        <section className="py-16 bg-primary text-primary-foreground">
          <div className="container mx-auto px-4">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              className="text-center mb-12"
            >
              <div className="w-16 h-16 rounded-full bg-white/10 flex items-center justify-center mx-auto mb-6">
                <PiggyBank className="h-8 w-8 text-accent" />
              </div>
              <h2 className="text-2xl md:text-3xl font-bold mb-4">
                {financialPlan.projectedResults.title}
              </h2>
              <p className="text-primary-foreground/80">
                نقطة التعادل: <span className="font-bold text-accent">{financialPlan.projectedResults.breakEvenPoint}</span>
              </p>
            </motion.div>

            <div className="grid md:grid-cols-3 gap-6 max-w-4xl mx-auto">
              {financialPlan.projectedResults.years.map((year, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.5, delay: index * 0.15 }}
                >
                  <Card className="bg-white/10 border-white/20 text-primary-foreground">
                    <CardHeader className="text-center pb-2">
                      <CardTitle className="text-lg">{year.year}</CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      <div className="flex items-center justify-between p-3 rounded-lg bg-white/5">
                        <span className="text-sm">الإيرادات</span>
                        <span className="font-bold flex items-center gap-1">
                          <ArrowUpRight className="h-4 w-4 text-accent" />
                          {formatCurrency(year.revenue)}
                        </span>
                      </div>
                      <div className="flex items-center justify-between p-3 rounded-lg bg-white/5">
                        <span className="text-sm">التكاليف</span>
                        <span className="font-bold flex items-center gap-1">
                          <ArrowDownRight className="h-4 w-4 text-destructive" />
                          {formatCurrency(year.costs)}
                        </span>
                      </div>
                      <div className={`flex items-center justify-between p-3 rounded-lg ${year.result >= 0 ? 'bg-accent/20' : 'bg-destructive/20'}`}>
                        <span className="text-sm">النتيجة</span>
                        <span className={`font-bold ${year.result >= 0 ? 'text-accent' : 'text-destructive'}`}>
                          {year.result >= 0 ? '+' : ''}{formatCurrency(year.result)}
                        </span>
                      </div>
                    </CardContent>
                  </Card>
                </motion.div>
              ))}
            </div>
          </div>
        </section>

        {/* Navigation */}
        <section className="py-12 bg-background border-t border-border">
          <div className="container mx-auto px-4">
            <div className="flex flex-col sm:flex-row items-center justify-between gap-4">
              <Button asChild variant="outline" className="group">
                <Link href="/">
                  <Home className="ml-2 h-4 w-4" />
                  العودة للرئيسية
                </Link>
              </Button>
              <div className="flex items-center gap-4">
                <Button asChild variant="outline" className="group">
                  <Link href="/production">
                    <ChevronLeft className="ml-2 h-4 w-4 rotate-180" />
                    خطة الإنتاج
                  </Link>
                </Button>
                <Button asChild className="group">
                  <Link href="/customers">
                    شرائح العملاء
                    <ChevronLeft className="mr-2 h-4 w-4" />
                  </Link>
                </Button>
              </div>
            </div>
          </div>
        </section>
      </main>

      <Footer />
    </div>
  )
}
