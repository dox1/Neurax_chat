"use client"

import { useEffect, useState } from "react"
import { motion, AnimatePresence } from "framer-motion"
import { Newspaper, ChevronLeft } from "lucide-react"

const newsItems = [
  "يوم دراسي حول الوقاية من جرائم الفساد في المؤسسات العمومية الاقتصادية بالتعاون مع السلطة العليا للشفافية",
  "عهد جديد للصفقات العمومية: البوابة الإلكترونية رسمياً - مجانية التنافس ووداعاً للورق",
  "توقيع اتفاقية إطار لتعزيز التعاون في مجال الوقاية من الفساد ومكافحته",
  "منصة نوران: الحل الرقمي المبتكر للوقاية من جرائم الفساد في الصفقات العمومية",
]

export function NewsTicker() {
  const [currentIndex, setCurrentIndex] = useState(0)

  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentIndex((prev) => (prev + 1) % newsItems.length)
    }, 5000)
    return () => clearInterval(interval)
  }, [])

  return (
    <div className="bg-accent text-accent-foreground overflow-hidden">
      <div className="container mx-auto px-4">
        <div className="flex items-center h-10 gap-4">
          <div className="flex items-center gap-2 flex-shrink-0 border-l border-accent-foreground/20 pl-4">
            <Newspaper className="h-4 w-4" />
            <span className="text-sm font-semibold hidden sm:inline">آخر الأخبار</span>
          </div>
          <div className="flex-1 overflow-hidden relative">
            <AnimatePresence mode="wait">
              <motion.div
                key={currentIndex}
                initial={{ x: -100, opacity: 0 }}
                animate={{ x: 0, opacity: 1 }}
                exit={{ x: 100, opacity: 0 }}
                transition={{ duration: 0.5 }}
                className="flex items-center gap-2 text-sm whitespace-nowrap"
              >
                <ChevronLeft className="h-4 w-4 flex-shrink-0" />
                <span className="truncate">{newsItems[currentIndex]}</span>
              </motion.div>
            </AnimatePresence>
          </div>
          <div className="flex items-center gap-1 flex-shrink-0">
            {newsItems.map((_, index) => (
              <button
                key={index}
                onClick={() => setCurrentIndex(index)}
                className={`w-2 h-2 rounded-full transition-colors ${
                  index === currentIndex ? "bg-accent-foreground" : "bg-accent-foreground/30"
                }`}
                aria-label={`الخبر ${index + 1}`}
              />
            ))}
          </div>
        </div>
      </div>
    </div>
  )
}
