"use client"

import Link from "next/link"
import { motion } from "framer-motion"
import {
  ArrowLeft,
  Home,
  FileSearch,
  BookOpen,
  AlertOctagon,
  LayoutDashboard,
  BarChart3,
  Shield,
  MessageSquare,
  GraduationCap,
  Target,
} from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card"
import { Header } from "@/components/layout/header"
import { Footer } from "@/components/layout/footer"
import { PageHero } from "@/components/ui/page-hero"
import { services } from "@/lib/data"

const iconMap: Record<string, React.ComponentType<{ className?: string }>> = {
  FileSearch,
  BookOpen,
  AlertOctagon,
  LayoutDashboard,
  BarChart3,
  Shield,
  MessageSquare,
  GraduationCap,
  Target,
}

export default function ServicesPage() {
  return (
    <div className="min-h-screen flex flex-col">
      <Header />

      <main className="flex-1">
        <PageHero
          title={services.title}
          subtitle={services.subtitle}
          description="مجموعة متكاملة من الخدمات لدعم الشفافية والحكامة الجيدة ومكافحة الفساد"
          breadcrumbs={[
            { label: "الرئيسية", href: "/" },
            { label: "الخدمات", href: "/services" },
          ]}
        />

        <section className="py-16 md:py-24 bg-background">
          <div className="container mx-auto px-4">
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
              {services.items.map((service, index) => {
                const IconComponent = iconMap[service.icon] || Target
                return (
                  <motion.div
                    key={service.id}
                    initial={{ opacity: 0, y: 20 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    viewport={{ once: true }}
                    transition={{ duration: 0.5, delay: index * 0.1 }}
                  >
                    <Card className="h-full hover:shadow-xl hover:border-primary/30 transition-all duration-300 group">
                      <CardHeader>
                        <div className="w-16 h-16 rounded-xl bg-gradient-to-br from-primary to-primary/80 flex items-center justify-center mb-6 group-hover:scale-110 transition-transform">
                          <IconComponent className="h-8 w-8 text-primary-foreground" />
                        </div>
                        <CardTitle className="text-xl group-hover:text-primary transition-colors">
                          {service.title}
                        </CardTitle>
                        <CardDescription className="text-base">
                          {service.shortDescription}
                        </CardDescription>
                      </CardHeader>
                      <CardContent>
                        <Button asChild className="w-full group/btn">
                          <Link href={`/services/${service.id}`}>
                            عرض التفاصيل
                            <ArrowLeft className="mr-2 h-4 w-4 group-hover/btn:-translate-x-1 transition-transform" />
                          </Link>
                        </Button>
                      </CardContent>
                    </Card>
                  </motion.div>
                )
              })}
            </div>
          </div>
        </section>

        {/* CTA */}
        <section className="py-16 bg-primary text-primary-foreground">
          <div className="container mx-auto px-4">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              className="max-w-3xl mx-auto text-center"
            >
              <h2 className="text-2xl md:text-3xl font-bold mb-6">
                هل تحتاج إلى خدمة مخصصة؟
              </h2>
              <p className="text-lg text-primary-foreground/90 mb-8">
                تواصل معنا للحصول على استشارة مجانية وتعرف على كيفية الاستفادة من خدمات منصة نوران
              </p>
              <Button asChild size="lg" className="bg-accent hover:bg-accent/90 text-accent-foreground">
                <Link href="/contact">
                  تواصل معنا
                  <ArrowLeft className="mr-2 h-4 w-4" />
                </Link>
              </Button>
            </motion.div>
          </div>
        </section>

        {/* Navigation */}
        <section className="py-12 bg-background border-t border-border">
          <div className="container mx-auto px-4">
            <div className="flex flex-col sm:flex-row items-center justify-between gap-4">
              <Button asChild variant="outline" className="group">
                <Link href="/">
                  <Home className="ml-2 h-4 w-4" />
                  العودة للرئيسية
                </Link>
              </Button>
              <Button asChild className="group">
                <Link href="/articles">
                  المقالات
                  <ArrowLeft className="mr-2 h-4 w-4 group-hover:-translate-x-1 transition-transform" />
                </Link>
              </Button>
            </div>
          </div>
        </section>
      </main>

      <Footer />
    </div>
  )
}
